package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

//import javax.swing.text.html.HTMLDocument.HTMLReader.IsindexAction;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class TwoPlayers {
	private CoinStrategy strategy = new CoinStrategy(); // Strategy for generating moves and DP table
	private int player1Score = 0, player2Score = 0;// Store the score of players
	private int[] Randomcoins;// store the random coins
	private int[] Manualcoins;// Store the manual Coins
	private int[] Filecoins;// Store the manual Coins
	private String[] coinsStr;
	private boolean[] selectedCoins;// mark a selected coins
	private String first;
	private StringBuilder Results = new StringBuilder();
	private StringBuilder player2SelectedCoinsSequence = new StringBuilder();
	private StringBuilder player1SelectedCoinsSequence = new StringBuilder();
	private StringBuilder Table = new StringBuilder();
	private Label player2SelectedCoinLabel = new Label("Selected coin: ");
	private Label player2ExpectedResultLabel = new Label("Expected result: ");
	private Label player1SelectedCoinLabel = new Label("Selected coin: ");
	private Label player1ExpectedResultLabel = new Label("Expected result: ");

	private int[] buttomsCoin;
	private Button firstCoin;
	private Button lastCoin;
	private Boolean isplayer1Turn;

	public void TwoPlayersRandomStage(int numCoins, String Name1, String Name2, int min, int max) {
		first = chooseWhoStartsStage(Name1, Name2);
		if (first != null) {
			int number = numCoins;// the number of coins
			Randomcoins = strategy.generateRandomCoins(numCoins, min, max); // Generate random coin values
			int[][] dp = new int[number][number];// Calculate DP table based on the coins array
			selectedCoins = new boolean[number]; // Track selected coins

			BorderPane pane = new BorderPane();
			GridPane grid = new GridPane();
			Stage randomStage = new Stage();
			randomStage.setTitle("Coin Selection Game");// Stage Title
			updateCoins(Randomcoins);

			// Title label
			Label titleLabel = new Label("Coin Game");
			titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 30)); // Use a modern font and larger size
			titleLabel.setTextFill(Color.WHITE); // Softer white for a professional feel
			titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);"); // Add shadow for

			// Display generated coins
			Label CoinsLabel = new Label("Coins: " + strategy.arrayToString(Randomcoins));
			CoinsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
			CoinsLabel.setTextFill(Color.WHITE);
			CoinsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);"); // Add shadow

			// Buttons for game controls
			Button startButton = styleButton(" Start Game ");
			Button resultsButton = new Button(" Results of Game ");
			Button TableButton = new Button(" show dp table ");

			Label instructionsLabel = new Label(
					"How to Play: Pick a coin from either end. Maximize your score to win!");
			instructionsLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
//			instructionsLabel.setTextFill(Color.web("#FFD700")); // Gold text color
			instructionsLabel.setTextFill(Color.WHITE);
			instructionsLabel.setWrapText(true);
			instructionsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);"); // Add

			Label Turn = new Label();
			Turn.setFont(Font.font("Roboto", FontWeight.BOLD, 20));
			Turn.setTextFill(Color.WHITE);

			resultsButton.setDisable(true);
			TableButton.setDisable(true);
			firstCoin.setDisable(true);
			lastCoin.setDisable(true);

			Results = new StringBuilder();
			Table = new StringBuilder();
			player1SelectedCoinsSequence = new StringBuilder();
			player2SelectedCoinsSequence = new StringBuilder();

			if (first.equals(Name1)) {
				isplayer1Turn = true;
			} else {
				isplayer1Turn = false;
			}
			startButton.setOnAction(e -> {
				firstCoin.setDisable(false);
				lastCoin.setDisable(false);

				// to store Expected result
				player1Score = 0;
				player2Score = 0;
				if (isplayer1Turn) {
					Turn.setText(Name1 + "'s Turn");
				} else {
					Turn.setText(Name2 + "'s Turn");
				}

				player2SelectedCoinLabel.setText("Selected coin: ");
				player2ExpectedResultLabel.setText("Expected result: ");
				player1SelectedCoinLabel.setText("Selected coin: ");
				player1ExpectedResultLabel.setText("Expected result: ");
				startButton.setDisable(true);
				firstCoin.setOnAction(e1 -> {
					if (Randomcoins != null) {
						firstCoinSelect(Turn, Name1, Name2, Randomcoins, CoinsLabel, resultsButton, TableButton);
					}
				});
				lastCoin.setOnAction(e1 -> {
					if (Randomcoins != null) {
						lastCoinSelect(Turn, Name1, Name2, Randomcoins, CoinsLabel, resultsButton, TableButton);
					}

				});
			});

			resultsButton.setOnAction(e -> endGame(dp, Randomcoins, Name1, Name2));
			TableButton.setOnAction(e -> ShowTable(dp, Randomcoins));

			// Player section layout
			Label playerLabel = new Label(Name2);
			playerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
			playerLabel.setTextFill(Color.GREEN);

			VBox playerBox = new VBox(10, playerLabel, player2SelectedCoinLabel, player2ExpectedResultLabel);
			playerBox.setAlignment(Pos.CENTER);
			playerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

			// Computer section layout
			Label player1Label = new Label(Name1);
			player1Label.setTextFill(Color.GREEN);
			player1Label.setFont(Font.font("Arial", FontWeight.BOLD, 18));

			VBox computerBox = new VBox(10, player1Label, player1SelectedCoinLabel, player1ExpectedResultLabel);
			computerBox.setAlignment(Pos.CENTER);
			computerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

			grid.add(startButton, 3, 0);
			grid.add(Turn, 3, 1);
			grid.add(playerBox, 0, 2);
			grid.add(computerBox, 5, 2);
			grid.add(resultsButton, 3, 5);
			grid.add(TableButton, 3, 6);
			grid.add(firstCoin, 3, 2);
			grid.add(lastCoin, 4, 2);
			grid.setAlignment(Pos.CENTER);
			grid.setHgap(10);
			grid.setVgap(10);

			// Create a File Menu with proper labels and actions
			Menu Menu = new Menu("Game Options");

			// Exit Option with Confirmation
			MenuItem exitItem = new MenuItem("Exit Game");
			exitItem.setOnAction(e -> {
				Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION,
						"Are you sure you want to exit the game?", ButtonType.YES, ButtonType.NO);
				exitConfirmation.showAndWait().ifPresent(response -> {
					if (response == ButtonType.YES) {
						randomStage.close(); // Exit action
					}
				});
			});
			// Play Again Option
			MenuItem playAgainItem = new MenuItem("Play Again");
			playAgainItem.setOnAction(e -> {
				TableButton.setDisable(true);
				first = chooseWhoStartsStage(Name1, Name2);
				if (first != null) {
					if (first.equals(Name1)) {
						isplayer1Turn = true;
					} else {
						isplayer1Turn = false;
					}
					Turn.setText("");
					resetGame(player1SelectedCoinsSequence, player2SelectedCoinsSequence, player1SelectedCoinLabel,
							player1ExpectedResultLabel, player2SelectedCoinLabel, player2ExpectedResultLabel,
							startButton, numCoins, CoinsLabel, resultsButton, TableButton, null, true, false, Name1,
							Name2, min, max);
					updateCoins(Randomcoins);
					CoinsLabel.setText("Coins:" + strategy.arrayToString(Randomcoins));
				}
			});
			// Add items to the menu
			Menu.getItems().addAll(playAgainItem, new SeparatorMenuItem(), exitItem);

			VBox root = new VBox(20, titleLabel, instructionsLabel, CoinsLabel, grid);
			root.setAlignment(Pos.CENTER);
			root.setPadding(new Insets(20));
			pane.setCenter(root);
//						pane.setStyle("-fx-background-color: #0C6478;");
			pane.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
			MenuBar menuBar = new MenuBar();
			menuBar.getMenus().add(Menu);

			pane.setCenter(root);
			pane.setTop(menuBar);
			// Scene setup
			Scene scene = new Scene(pane, 600, 500);
			randomStage.setScene(scene);
			randomStage.show();
		}

	}

	// enter coins manually
	public void TwoPlayersManualStage(int numCoins, String Name1, String Name2) {
		BorderPane pane = new BorderPane();
		Stage stage = new Stage();
		stage.setTitle("Enter Coins");// stage Title

		// Title label
		Label titleLabel = new Label("Enter Coin Values");
		titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 18));
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");
		titleLabel.setTextFill(Color.WHITE);
		// Instructions
		Label instructionLabel = new Label("Please enter " + numCoins + " coin values:");
		instructionLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
		instructionLabel.setTextFill(Color.WHITE);
		// Create TextFields for each coin
		HBox coinInputBox = new HBox(10); // Space between TextFields
		coinInputBox.setAlignment(Pos.CENTER);
		TextField[] coinFields = new TextField[numCoins];

		for (int i = 0; i < numCoins; i++) {// field to store coins number according numCoins
			TextField coinField = new TextField();
			coinField.setPromptText("Coin " + (i + 1));// next
			coinField.setPrefWidth(60); // Set width for consistency
			coinFields[i] = coinField;
			coinInputBox.getChildren().add(coinField);// added field
		}
		Button startButton = styleButton("Start Game");
		startButton.setDisable(true); // Disabled until all fields are filled

		// Enable start button only when all TextFields have valid input
		for (TextField coinField : coinFields) {
			coinField.textProperty().addListener((observable, oldValue, newValue) -> {
				startButton.setDisable(!areFilled(coinFields));
			});
		}

		startButton.setOnAction(e -> {
			// Read entered values and start the game
			Manualcoins = new int[numCoins];
			try {
				for (int i = 0; i < numCoins; i++) {
					int value = Integer.parseInt(coinFields[i].getText().trim());
					if (value <= 0) {
						throw new NumberFormatException(); // Treat non-positive numbers as invalid
					}
					Manualcoins[i] = value;
				}
			} catch (NumberFormatException ex) {
				showAlert("Exception", "You should enter only positive numbers. Please try again.");
				return;
			}
			stage.close(); // Close this window and proceed to the game

			ManualStage(numCoins, Manualcoins, Name1, Name2);// open stage to start actual game
		});
		// Root layout
		VBox root = new VBox(15, titleLabel, instructionLabel, coinInputBox, startButton);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));

		pane.setCenter(root);
		pane.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		Scene scene = new Scene(pane, 400, 250);
		stage.setScene(scene);
		stage.show();
	}

	private void ManualStage(int numCoins, int[] coinValues, String Name1, String Name2) {// interface for game
		first = chooseWhoStartsStage(Name1, Name2);
		if (first != null) {
			Stage manualStage = new Stage();
			int number = numCoins;
			int[][] dp = new int[number][number];// Calculate DP table based on the coins array
			selectedCoins = new boolean[numCoins]; // Track selected coins

			BorderPane paneb = new BorderPane();
			manualStage.setTitle("Coin Selection Game");
			updateCoins(Manualcoins);

			// Title label
			Label TitleLabel = new Label("Coin Game");
			TitleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 30)); // Use a modern font and larger size
			TitleLabel.setTextFill(Color.WHITE); // Softer white for a professional feel
			TitleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

			// Display generated coins
			Label coinsLabel = new Label("Coins: " + strategy.arrayToString(coinValues));
			coinsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
			coinsLabel.setTextFill(Color.WHITE);
			// Buttons for game controls
			Button StartGameButton = styleButton(" Start Game ");
			Button ResultButton = new Button("Results of Game");
			Button TableButton = new Button(" Show dp table ");

			Label instructionsLabel = new Label(
					"How to Play: Pick a coin from either end. Maximize your score to win!");
			instructionsLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
			instructionsLabel.setTextFill(Color.WHITE);
			instructionsLabel.setWrapText(true);
			instructionsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);"); // Add

			Label Turn = new Label("");
			Turn.setFont(Font.font("Roboto", FontWeight.BOLD, 20));
			Turn.setTextFill(Color.WHITE);

			ResultButton.setDisable(true);
			TableButton.setDisable(true);
			firstCoin.setDisable(true);
			lastCoin.setDisable(true);

			Results = new StringBuilder();
			Table = new StringBuilder();
			player1SelectedCoinsSequence = new StringBuilder();
			player2SelectedCoinsSequence = new StringBuilder();

			if (first.equals(Name1)) {
				isplayer1Turn = true;
			} else {
				isplayer1Turn = false;
			}
			StartGameButton.setOnAction(e -> {
				firstCoin.setDisable(false);
				lastCoin.setDisable(false);
				// to store Expected result
				player1Score = 0;
				player2Score = 0;
				if (isplayer1Turn) {
					Turn.setText(Name1 + "'s Turn");
				} else {
					Turn.setText(Name2 + "'s Turn");
				}

				player2SelectedCoinLabel.setText("Selected coin: ");
				player2ExpectedResultLabel.setText("Expected result: ");
				player1SelectedCoinLabel.setText("Selected coin: ");
				player1ExpectedResultLabel.setText("Expected result: ");
				StartGameButton.setDisable(true);
				firstCoin.setOnAction(e1 -> {
					if (Manualcoins != null) {
						firstCoinSelect(Turn, Name1, Name2, Manualcoins, coinsLabel, ResultButton, TableButton);
					}
				});
				lastCoin.setOnAction(e1 -> {
					if (Manualcoins != null) {
						lastCoinSelect(Turn, Name1, Name2, Manualcoins, coinsLabel, ResultButton, TableButton);
					}

				});
			});

			ResultButton.setOnAction(e -> endGame(dp, Manualcoins, Name1, Name2));
			TableButton.setOnAction(e -> ShowTable(dp, Manualcoins));

			// Player section layout
			Label playerLabel = new Label(Name2);
			playerLabel.setTextFill(Color.GREEN);
			playerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
			VBox playerBox = new VBox(10, playerLabel, player2SelectedCoinLabel, player2ExpectedResultLabel);
			playerBox.setAlignment(Pos.CENTER);
			playerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

			// Computer section layout
			Label player1Label = new Label(Name1);
			player1Label.setTextFill(Color.GREEN);
			player1Label.setFont(Font.font("Arial", FontWeight.BOLD, 18));
			VBox computerBox = new VBox(10, player1Label, player1SelectedCoinLabel, player1ExpectedResultLabel);
			computerBox.setAlignment(Pos.CENTER);
			computerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

			// Horizontal box for Player and Computer sections
			HBox playerComputerHBox = new HBox(20, playerBox, computerBox);
			playerComputerHBox.setAlignment(Pos.CENTER);

			// Create a File Menu with proper labels and actions
			Menu fileMenu = new Menu("Game Options");

			// Exit Option with Confirmation
			MenuItem exitItem = new MenuItem("Exit Game");
			exitItem.setOnAction(e1 -> {
				Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION,
						"Are you sure you want to exit the game?", ButtonType.YES, ButtonType.NO);
				exitConfirmation.showAndWait().ifPresent(response -> {
					if (response == ButtonType.YES) {
						manualStage.close(); // Exit action
					}
				});
			});

			// Play Again Option
			MenuItem playAgainItem = new MenuItem("Play Again");
			// Play Again Option
			playAgainItem.setOnAction(e1 -> {
				manualStage.close();
				Turn.setText("");
				TwoPlayersManualStage(numCoins, Name1, Name2);
				resetGame(player2SelectedCoinsSequence, player1SelectedCoinsSequence, player2SelectedCoinLabel,
						player2ExpectedResultLabel, player1SelectedCoinLabel, player1ExpectedResultLabel,
						StartGameButton, numCoins, coinsLabel, ResultButton, TableButton, Manualcoins, false, false,
						Name1, Name2, 0, 0);
				updateCoins(Manualcoins);
				coinsLabel.setText("Coins:" + strategy.arrayToString(Manualcoins));
			});

			// Add items to the menu
			fileMenu.getItems().addAll(playAgainItem, new SeparatorMenuItem(), exitItem);

			GridPane grid = new GridPane();
			grid.add(StartGameButton, 3, 0);
			grid.add(Turn, 3, 1);
			grid.add(playerBox, 0, 2);
			grid.add(computerBox, 5, 2);
			grid.add(ResultButton, 3, 5);
			grid.add(TableButton, 3, 6);
			grid.add(firstCoin, 3, 2);
			grid.add(lastCoin, 4, 2);
			grid.setAlignment(Pos.CENTER);
			grid.setHgap(10);
			grid.setVgap(10);

			// Root layout
			VBox root = new VBox(20, TitleLabel, instructionsLabel, coinsLabel, grid);
			root.setAlignment(Pos.CENTER);
			root.setPadding(new Insets(20));
//			root.setStyle("-fx-background-color: #34495e;");
			paneb.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
			MenuBar menuBar = new MenuBar();
			menuBar.getMenus().add(fileMenu);

			paneb.setTop(menuBar);
			paneb.setCenter(root);
//			paneb.setStyle("-fx-background-color: #0C6478;");
			// Scene setup
			Scene scene = new Scene(paneb, 600, 500);
			manualStage.setScene(scene);
			manualStage.show();
		}
	}

	public void TwoPlayersFileStage(int numCoins, String Name1, String Name2) {// فيها غلط
		Stage primaryStage = new Stage();
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open Coin File");
		fileChooser.setInitialDirectory(new File("c:\\"));
		File file = fileChooser.showOpenDialog(primaryStage);

		if (file != null) {
			try (Scanner scanner = new Scanner(file)) {
				StringBuilder fileContent = new StringBuilder();
				while (scanner.hasNextLine()) {
					fileContent.append(scanner.nextLine()).append(",");
				}
				for (int i = 0; i < numCoins; i++) {
					coinsStr = fileContent.toString().split(",");

				}
				Filecoins = new int[numCoins];
				int index = 0; // Tracks the current position in the `coinsStr` array
				int filledCount = 0; // Tracks how many valid positive numbers have been added to `Filecoins`

				while (filledCount < numCoins) {
					// Cycle through `coinsStr` repeatedly if needed
					String coinStr = coinsStr[index % coinsStr.length].trim();
					index++; // Move to the next number (wraps around due to `%`)

					try {
						int value = Integer.parseInt(coinStr); // Parse the value
						if (value > 0) { // Add only positive numbers
							Filecoins[filledCount++] = value;
						}
						// Skip negative numbers and zero automatically
					} catch (NumberFormatException ex) {
						// Skip invalid entries (non-numeric values)
						System.err.println("Invalid entry skipped: " + coinStr);
					}
				}

				selectedCoins = new boolean[Filecoins.length]; // Track selected coins

				// Initialize the game stage with loaded coins
				OpenFileStage(primaryStage, numCoins, Name1, Name2);

			} catch (FileNotFoundException e) {
				showAlert("ErrorFile", "File not found.");
			} catch (NumberFormatException e) {
				showAlert("ErrorFile", "Invalid file format. Please ensure the file contains only integers.");
			}
		}
	}

	private void OpenFileStage(Stage primaryStage, int numCoins, String Name1, String Name2) {
		first = chooseWhoStartsStage(Name1, Name2);
		if (first != null) {
			int number = numCoins;
			int[][] dp = new int[number][number];// Calculate DP table based on the coins array
			selectedCoins = new boolean[number];
			BorderPane pane = new BorderPane();
			Stage fileStage = new Stage();
			fileStage.setTitle(" Coin Selection Game");
			updateCoins(Filecoins);

			Label titleLabel = new Label("Coin Game");
			titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 30)); // Use a modern font and larger size
			titleLabel.setTextFill(Color.WHITE); // Softer white for a professional feel
			titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

			Label coinsLabel = new Label("Coins: " + strategy.arrayToString(Filecoins));
			coinsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
			coinsLabel.setTextFill(Color.WHITE);
			coinsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

			Button startButton = styleButton("Start Game");

			Button resultsButton = new Button("Results of Game");
			Button TableButton = new Button(" Show dp table ");
			Label instructionsLabel = new Label(
					"How to Play: Pick a coin from either end. Maximize your score to win!");
			instructionsLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
			instructionsLabel.setTextFill(Color.WHITE);
			instructionsLabel.setWrapText(true);
			instructionsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);"); // Add

			Label Turn = new Label("");
			Turn.setFont(Font.font("Roboto", FontWeight.BOLD, 20));
			Turn.setTextFill(Color.WHITE);

			resultsButton.setDisable(true);
			TableButton.setDisable(true);
			firstCoin.setDisable(true);
			lastCoin.setDisable(true);

			player2SelectedCoinsSequence = new StringBuilder();
			player1SelectedCoinsSequence = new StringBuilder();
			Results = new StringBuilder();

			Results = new StringBuilder();
			Table = new StringBuilder();
			player1SelectedCoinsSequence = new StringBuilder();
			player2SelectedCoinsSequence = new StringBuilder();

			if (first.equals(Name1)) {
				isplayer1Turn = true;
			} else {
				isplayer1Turn = false;
			}
			startButton.setOnAction(e -> {
				firstCoin.setDisable(false);
				lastCoin.setDisable(false);
				// to store Expected result
				player1Score = 0;
				player2Score = 0;
				if (isplayer1Turn) {
					Turn.setText(Name1 + "'s Turn");
				} else {
					Turn.setText(Name2 + "'s Turn");
				}

				player2SelectedCoinLabel.setText("Selected coin: ");
				player2ExpectedResultLabel.setText("Expected result: ");
				player1SelectedCoinLabel.setText("Selected coin: ");
				player1ExpectedResultLabel.setText("Expected result: ");
				startButton.setDisable(true);
				firstCoin.setOnAction(e1 -> {
					if (firstCoin != null) {
						firstCoinSelect(Turn, Name1, Name2, Filecoins, coinsLabel, resultsButton, TableButton);
					}
				});
				lastCoin.setOnAction(e1 -> {
					if (Filecoins != null) {
						lastCoinSelect(Turn, Name1, Name2, Filecoins, coinsLabel, resultsButton, TableButton);
					}

				});
			});
			resultsButton.setOnAction(e -> endGame(dp, Filecoins, Name1, Name2));
			TableButton.setOnAction(e -> ShowTable(dp, Filecoins));

			// Create a File Menu with proper labels and actions
			Menu Menu = new Menu("Game Options");

			// Exit Option with Confirmation
			MenuItem exitItem = new MenuItem("Exit Game");
			exitItem.setOnAction(e1 -> {
				Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION,
						"Are you sure you want to exit the game?", ButtonType.YES, ButtonType.NO);
				exitConfirmation.showAndWait().ifPresent(response -> {
					if (response == ButtonType.YES) {
						fileStage.close(); // Exit action
					}
				});
			});

			// Play Again Option
			MenuItem playAgainItem = new MenuItem("Play Again");
			// Play Again Option
			playAgainItem.setOnAction(e1 -> {
				fileStage.close();
				Turn.setText("");
				resetGame(player1SelectedCoinsSequence, player2SelectedCoinsSequence, player1SelectedCoinLabel,
						player1ExpectedResultLabel, player2SelectedCoinLabel, player2ExpectedResultLabel, startButton,
						number, coinsLabel, resultsButton, TableButton, null, false, true, Name1, Name2, 0, 0);
				coinsLabel.setText("Coins:" + strategy.arrayToString(Filecoins));
			});
			// Add items to the menu
			Menu.getItems().addAll(playAgainItem, new SeparatorMenuItem(), exitItem);

			Label player1Label = new Label(Name1);
			player1Label.setTextFill(Color.GREEN);
			player1Label.setFont(Font.font("Arial", FontWeight.BOLD, 18));
			VBox player1Box = new VBox(10, player1Label, player1SelectedCoinLabel, player1ExpectedResultLabel);
			player1Box.setAlignment(Pos.CENTER);
			player1Box.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

			Label player2Label = new Label(Name2);
			player2Label.setTextFill(Color.GREEN);
			player2Label.setFont(Font.font("Arial", FontWeight.BOLD, 18));
			VBox player2Box = new VBox(10, player2Label, player2SelectedCoinLabel, player2ExpectedResultLabel);
			player2Box.setAlignment(Pos.CENTER);
			player2Box.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

			GridPane grid = new GridPane();
			grid.add(startButton, 3, 0);
			grid.add(Turn, 3, 1);
			grid.add(player1Box, 0, 2);
			grid.add(player2Box, 5, 2);
			grid.add(resultsButton, 3, 5);
			grid.add(TableButton, 3, 6);
			grid.add(firstCoin, 3, 2);
			grid.add(lastCoin, 4, 2);
			grid.setAlignment(Pos.CENTER);
			grid.setHgap(10);
			grid.setVgap(10);

			grid.setAlignment(Pos.CENTER);
			grid.setHgap(10);
			grid.setVgap(10);

			VBox root = new VBox(20, titleLabel, instructionsLabel, coinsLabel, grid);
			root.setAlignment(Pos.CENTER);
			root.setPadding(new Insets(20));

			MenuBar menuBar = new MenuBar();
			menuBar.getMenus().add(Menu);

			pane.setCenter(root);
			pane.setTop(menuBar);
//			pane.setStyle("-fx-background-color: #0C6478;");
			pane.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
			Scene scene = new Scene(pane, 600, 500);
			fileStage.setScene(scene);
			fileStage.show();
		}
	}

	// Helper method to check if all TextFields are filled
	private boolean areFilled(TextField[] fields) {
		for (TextField field : fields) {
			if (field.getText().trim().isEmpty()) {
				return false;
			}
		}
		return true;
	}

	private void ShowTable(int[][] table, int[] coins) {
		// Initialize the StringBuilder to store the table content
		StringBuilder Table = new StringBuilder();

		// Fill and append the table content
		strategy.fillDpTable(coins, table);
		strategy.appendDpTable(table, Table, coins);

		// Create a new Stage to show the table
		Stage tableStage = new Stage();

		// Title Label for the table view
		Label titleLabel = new Label("Final Table");
		titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
		titleLabel.setTextFill(Color.WHITE);

		// Create a TextArea to display the table content, set it to non-editable
		TextArea tableTextArea = new TextArea(Table.toString());
		tableTextArea.setWrapText(true);
		tableTextArea.setEditable(false); // Make sure it's non-editable
		tableTextArea.setStyle("-fx-font-family: Arial; -fx-font-size: 14px;");

		// Wrap the TextArea in a ScrollPane to enable scrolling for larger tables
		ScrollPane scrollPane = new ScrollPane(tableTextArea);
		scrollPane.setFitToWidth(true); // Ensures text fits within the width of the pane

		// Create a button to close the table view
		Button closeButton = new Button("Close");
		closeButton.setOnAction(e -> tableStage.close());

		// Create a VBox layout to hold the title, scrollable table, and close button
		VBox layout = new VBox(20);
		layout.setStyle("-fx-padding: 20px; -fx-background-color: #0C6478; -fx-alignment: center;");
		layout.setAlignment(Pos.CENTER);
		layout.getChildren().addAll(titleLabel, scrollPane, closeButton);

		// Create a Scene with the layout
		Scene tableScene = new Scene(layout, 500, 400);

		// Set the scene for the table stage and show it
		tableStage.setScene(tableScene);
		tableStage.setTitle("Dynamic Table View");
		tableStage.show();
	}

	private void endGame(int[][] table, int[] coins, String Name1, String Name2) {
		// Prepare the result string
		StringBuilder Results = new StringBuilder();
		String winner;

		if (player1Score > player2Score) {
			winner = Name1;
		} else if (player1Score < player2Score) {
			winner = Name2;
		} else {
			winner = "It's a tie!";
		}

		Results.append("\nGame Ended!\n").append("Final Score  " + Name1).append(" " + player1Score)
				.append(" ," + Name2).append(" " + player2Score).append("\n\nSelected coins:").append("\n")
				.append(Name2).append(player2SelectedCoinsSequence).append("/ " + Name1)
				.append(player1SelectedCoinsSequence).append("\n\n").append(winner).append(" Wins!").append("\n");

		// Create a new Stage for displaying results
		Stage resultsStage = new Stage();

		// Title Label
		Label titleLabel = new Label("Game Over!");
		titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
		titleLabel.setTextFill(Color.WHITE);

		// Final Score Label
		Label finalScoreLabel = new Label(
				"Final Score  " + Name1 + ": " + player1Score + ", " + Name2 + ": " + player2Score);
		finalScoreLabel.setStyle("-fx-font-size: 18px;");
		finalScoreLabel.setTextFill(Color.WHITE);

		// Coins Selected Label
		Label coinsLabel = new Label("Selected Coins:");
		coinsLabel.setStyle("-fx-font-size: 18px;");
		coinsLabel.setTextFill(Color.WHITE);
		Label playerCoinsLabel = new Label(Name1 + ": " + player1SelectedCoinsSequence);
		playerCoinsLabel.setTextFill(Color.WHITE);
		Label computerCoinsLabel = new Label(Name2 + ": " + player2SelectedCoinsSequence);
		computerCoinsLabel.setTextFill(Color.WHITE);
		// Winner Label
		Label winnerLabel = new Label(winner + " Wins!");
		winnerLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
		winnerLabel.setTextFill(Color.WHITE);

		// Button to close the window
		Button closeButton = new Button("Close");
		closeButton.setOnAction(e -> resultsStage.close());

		// Layout to hold all labels and buttons
		VBox layout = new VBox(15);
		layout.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		layout.setAlignment(Pos.CENTER);
		layout.getChildren().addAll(titleLabel, finalScoreLabel, coinsLabel, computerCoinsLabel, playerCoinsLabel,
				winnerLabel, closeButton);

		// Scene for results
		Scene resultsScene = new Scene(layout, 400, 350);

		// Set the scene for the stage and show
		resultsStage.setScene(resultsScene);
		resultsStage.setTitle("Game Results");
		resultsStage.show();
	}

	private void resetGame(StringBuilder playerSelectedCoinsSequence, StringBuilder computerSelectedCoinsSequence,
			Label playerSelectedCoinLabel, Label playerExpectedResultLabel, Label computerSelectedCoinLabel,
			Label computerExpectedResultLabel, Button startButton, int numCoins, Label coinsLabel, Button resultButton,
			Button TableButton, int[] manualCoins, boolean isRandomMode, boolean IsFile, String name1, String name2,
			int min, int max) {

		// Reset scores
		player1Score = 0;
		player2Score = 0;

		// Set up coins based on game mode
		if (isRandomMode) {
			// Generate a new random sequence of coins
			Randomcoins = strategy.generateRandomCoins(numCoins, min, max);
			strategy.updateCoinsDisplay(Randomcoins, selectedCoins, coinsLabel);
		} else if (IsFile) {
			// Use coins from file if fileStage is provided in manual mode
			TwoPlayersFileStage(numCoins, name1, name2);
			strategy.updateCoinsDisplay(Filecoins, selectedCoins, coinsLabel);
		} else {
			// Use manually entered coins for manual mode without fileStage
			Manualcoins = manualCoins.clone();
			strategy.updateCoinsDisplay(Manualcoins, selectedCoins, coinsLabel);
		}

		// Reset selected coins array to mark all coins as unselected
		selectedCoins = new boolean[numCoins];

		// Clear the selected coins sequence for both player and computer
		playerSelectedCoinsSequence.setLength(0);
		computerSelectedCoinsSequence.setLength(0);

		// Update the UI labels to clear previous selections and results
		playerSelectedCoinLabel.setText("Selected coins: ");
		playerExpectedResultLabel.setText("Expected result: 0");
		computerSelectedCoinLabel.setText("Selected coins: ");
		computerExpectedResultLabel.setText("Expected result: 0");

		// Enable the start button and disable the pick buttons initially
		startButton.setDisable(false);
		resultButton.setDisable(true);
		TableButton.setDisable(true);
		firstCoin.setDisable(true);
		lastCoin.setDisable(true);
	}

	public String chooseWhoStartsStage(String Name1, String Name2) {
		// Create a class-level variable to hold the result
		final String[] result = new String[1]; // To hold the result

		// Stage to choose who starts
		Stage startChoiceStage = new Stage();
		startChoiceStage.setTitle("Choose Who Starts");

		// Label and buttons to select who starts
		Label chooseWhoStartsLabel = new Label("Who will start first?");
		Button player1Button = styleButton(Name1);
		Button player2Button = styleButton(Name2);

		// Style for the label
		chooseWhoStartsLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: white;");

		// Button action handlers
		player1Button.setOnAction(e -> {
			result[0] = Name1; // Player 1 starts
			startChoiceStage.close(); // Close the start choice stage
		});

		player2Button.setOnAction(e -> {
			result[0] = Name2; // Player 2 starts
			startChoiceStage.close(); // Close the start choice stage
		});

		// Layout for Start Choice Stage
		VBox startChoiceLayout = new VBox(20, chooseWhoStartsLabel, player1Button, player2Button);
		startChoiceLayout.setAlignment(Pos.CENTER);
		startChoiceLayout.setPadding(new Insets(20));
		startChoiceLayout.setSpacing(20); // Add spacing between elements
		Scene startChoiceScene = new Scene(startChoiceLayout, 350, 250);

		// Set custom background color for the scene
		startChoiceLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");

		// Apply shadow effect to buttons for a 3D look
		player1Button.setEffect(new DropShadow(10, Color.BLACK));
		player2Button.setEffect(new DropShadow(10, Color.BLACK));

		// Show the start choice stage
		startChoiceStage.setScene(startChoiceScene);
		startChoiceStage.showAndWait(); // Wait for the user to select the player

		// Return the result after user input
		return result[0]; // This will return the name of the player who starts
	}

	private void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle(title);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public int[] getFirstAndLastCoin(int[] coins, boolean[] selectedCoins) {
		int firstCoinIndex = -1;
		int lastCoinIndex = -1;
		int n = selectedCoins.length;

		int i = 0, j = n - 1;

		// Find the first unselected coin (index)
		while (i < n && selectedCoins[i]) {
			i++;
		}
		// Find the last unselected coin (index)
		while (j >= 0 && selectedCoins[j]) {
			j--;
		}

		// If there's a valid unselected coin, store the indices
		if (i < n) {
			firstCoinIndex = coins[i];
		}
		if (j >= 0) {
			lastCoinIndex = coins[j];
		}

		// Optionally, you can return the indices or the coin values depending on your
		// use case
		// Here we are returning indices
		return new int[] { firstCoinIndex, lastCoinIndex };
	}

	private void lastCoinSelect(Label Turn, String Name1, String Name2, int[] coins, Label CoinsLabel,
			Button resultsButton, Button tableButton) {
		if (isplayer1Turn) {
			Turn.setText(Name2 + "'s Turn");
			int selectedCoinIndex = strategy.TwoPlayerGame(coins, selectedCoins, "l");
			selectedCoins[selectedCoinIndex] = true;
			player1Score += coins[selectedCoinIndex];

			// Append the selected coin to the sequence
			if (player1SelectedCoinsSequence.length() > 0) {
				player1SelectedCoinsSequence.append(", ");
			}
			player1SelectedCoinsSequence.append(coins[selectedCoinIndex]);

			// Update labels with the sequence of selected coins
			player1SelectedCoinLabel.setText("Selected coins: " + player1SelectedCoinsSequence.toString());
			player1ExpectedResultLabel.setText("Expected result: " + player1Score);

			// Update the coin display
			strategy.updateCoinsDisplay(coins, selectedCoins, CoinsLabel);

			// Check if all coins are selected
			if (areAllCoinsSelected()) {
				Turn.setText("");
				firstCoin.setDisable(true);
				lastCoin.setDisable(true);
				resultsButton.setDisable(false);
				tableButton.setDisable(false);
			}
			isplayer1Turn = false;
			updateCoins(coins); // Update first and last coin values
		} else {
			Turn.setText(Name1 + "'s  Turn");
			int selectedCoinIndex = strategy.TwoPlayerGame(coins, selectedCoins, "l");
			selectedCoins[selectedCoinIndex] = true;
			player2Score += coins[selectedCoinIndex];

			// Append the selected coin to the sequence
			if (player2SelectedCoinsSequence.length() > 0) {
				player2SelectedCoinsSequence.append(", ");
			}
			player2SelectedCoinsSequence.append(coins[selectedCoinIndex]);

			// Update labels with the sequence of selected coins
			player2SelectedCoinLabel.setText("Selected coins: " + player2SelectedCoinsSequence.toString());
			player2ExpectedResultLabel.setText("Expected result: " + player2Score);

			// Update the coin display
			strategy.updateCoinsDisplay(coins, selectedCoins, CoinsLabel);

			// Check if all coins are selected
			if (areAllCoinsSelected()) {
				Turn.setText("");
				firstCoin.setDisable(true);
				lastCoin.setDisable(true);
				resultsButton.setDisable(false);
				tableButton.setDisable(false);
			}
			isplayer1Turn = true;
			updateCoins(coins); // Update first and last coin values
		}
	}

	private void firstCoinSelect(Label Turn, String Name1, String Name2, int[] coins, Label CoinsLabel,
			Button resultsButton, Button tableButton) {
		if (isplayer1Turn) {
			Turn.setText(Name2 + "'s  Turn");
			int selectedCoinIndex = strategy.TwoPlayerGame(coins, selectedCoins, "F");
			selectedCoins[selectedCoinIndex] = true;
			player1Score += coins[selectedCoinIndex];

			// Append the selected coin to the sequence
			if (player1SelectedCoinsSequence.length() > 0) {
				player1SelectedCoinsSequence.append(", ");
			}
			player1SelectedCoinsSequence.append(coins[selectedCoinIndex]);

			// Update labels with the sequence of selected coins
			player1SelectedCoinLabel.setText("Selected coins: " + player1SelectedCoinsSequence.toString());
			player1ExpectedResultLabel.setText("Expected result: " + player1Score);

			// Update the coin display
			strategy.updateCoinsDisplay(coins, selectedCoins, CoinsLabel);

			// Check if all coins are selected
			if (areAllCoinsSelected()) {
				Turn.setText("");
				firstCoin.setDisable(true);
				lastCoin.setDisable(true);
				resultsButton.setDisable(false);
				tableButton.setDisable(false);
			}
			isplayer1Turn = false;
			updateCoins(coins); // Update first and last coin values
		} else {
			Turn.setText(Name1 + "'s  Turn");
			int selectedCoinIndex = strategy.TwoPlayerGame(coins, selectedCoins, "f");
			selectedCoins[selectedCoinIndex] = true;
			player2Score += coins[selectedCoinIndex];

			// Append the selected coin to the sequence
			if (player2SelectedCoinsSequence.length() > 0) {
				player2SelectedCoinsSequence.append(", ");
			}
			player2SelectedCoinsSequence.append(coins[selectedCoinIndex]);

			// Update labels with the sequence of selected coins
			player2SelectedCoinLabel.setText("Selected coins: " + player2SelectedCoinsSequence.toString());
			player2ExpectedResultLabel.setText("Expected result: " + player2Score);

			// Update the coin display
			strategy.updateCoinsDisplay(coins, selectedCoins, CoinsLabel);

			// Check if all coins are selected
			if (areAllCoinsSelected()) {
				Turn.setText("");
				firstCoin.setDisable(true);
				lastCoin.setDisable(true);
				resultsButton.setDisable(false);
				tableButton.setDisable(false);
			}
			isplayer1Turn = true;
			updateCoins(coins); // Update first and last coin values
		}
	}

	private void updateCoins(int[] coins) {
		buttomsCoin = getFirstAndLastCoin(coins, selectedCoins);

		if (firstCoin == null) {
			firstCoin = styleButton("" + buttomsCoin[0]); // Initialize if null
		} else {
			firstCoin.setText("" + buttomsCoin[0]); // Update button text with the actual index
		}

		if (lastCoin == null) {
			lastCoin = styleButton("" + buttomsCoin[1]); // Initialize if null
		} else {
			lastCoin.setText("" + buttomsCoin[1]); // Update button text with the actual index
		}

	}

	private boolean areAllCoinsSelected() {
		for (boolean selected : selectedCoins) {
			if (!selected) {
				return false; // If there is at least one unselected coin, return false
			}
		}
		return true; // All coins are selected
	}

	// style the buttons
	private Button styleButton(String text) {

		String buttonStyle = "-fx-background-color: linear-gradient(to right, #09D1C7, #15919B,#09D1C7); -fx-text-fill: white; -fx-background-radius: 30;";
		String buttonHoverStyle = "-fx-background-color: linear-gradient(to right,  #15919B, #09D1C7,#15919B); -fx-text-fill: white; -fx-background-radius: 30;";
		// One Player Button
		Button button = new Button(text);
		button.setStyle(buttonStyle);
		button.setOnMouseEntered(e -> button.setStyle(buttonStyle));
		button.setOnMouseExited(e -> button.setStyle(buttonHoverStyle));
		return button;
	}
}
