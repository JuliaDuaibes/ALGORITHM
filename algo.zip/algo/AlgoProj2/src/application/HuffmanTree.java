package application;

public class HuffmanTree {
    private HuffmanNode root;

    public void buildTreeFromFrequencies(int[] frequencies) {
        Heap heap = new Heap(256);
        for (int i = 0; i < frequencies.length; i++) {
            if (frequencies[i] > 0) {
                heap.insert(new HuffmanNode((byte) i, frequencies[i]));
            }
        }

        while (heap.size() > 1) {
            HuffmanNode left = heap.extractMin();
            HuffmanNode right = heap.extractMin();
            HuffmanNode parent = new HuffmanNode(left.getFrequency() + right.getFrequency(), left, right);
            heap.insert(parent);
        }

        root = heap.extractMin();
    }

    public void generateCodes(String[] codes) {
        generateCodesRecursive(root, "", codes);
    }

    private void generateCodesRecursive(HuffmanNode node, String code, String[] codes) {
        if (node.isLeaf()) {
            codes[node.getCharacter() & 0xFF] = code;
        } else {
            generateCodesRecursive(node.getLeft(), code + "0", codes);
            generateCodesRecursive(node.getRight(), code + "1", codes);
        }
    }

    public HuffmanNode getRoot() {
        return root;
    }  
}