package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DataLoader {
    public static Graph loadFromFile(String fileName) {
        Graph graph = new Graph();
        try (Scanner sc = new Scanner(new File(fileName))) {
            // Read the number of cities and edges
            int numberOfVertices = sc.nextInt();
            int numberOfEdges = sc.nextInt();
            sc.nextLine(); // Consume the rest of the first line

            // Read city data
            for (int i = 0; i < numberOfVertices; i++) {
                if (sc.hasNextLine()) {
                    String line = sc.nextLine().trim();
                    String[] cityData = line.split("\\s+"); // Split by spaces
                    if (cityData.length < 3) {
//                        System.err.println("Invalid city data: " + line);
                        continue; // Skip invalid lines
                    }

                    String cityName = cityData[0];
                    try {
                        double latitude = Double.parseDouble(cityData[1]);
                        double longitude = Double.parseDouble(cityData[2]);

                        CaptalCityNode city = new CaptalCityNode(cityName, latitude, longitude);
                        graph.addCity(city); // Add the city to the graph
                    } catch (NumberFormatException e) {
//                        System.err.println("Invalid coordinates for city: " + cityName + " in line: " + line);
                    }
                }
            }
         // Read edge data
            for (int i = 0; i < numberOfEdges; i++) {
                if (sc.hasNextLine()) {
                    String line = sc.nextLine().trim();
                    String[] edgeData = line.split("\\s+"); // Split by spaces
                    if (edgeData.length < 4) {
                        System.err.println("Invalid edge data: " + line);
                        continue; // Skip invalid lines
                    }

                    String sourceName = edgeData[0];
                    String targetName = edgeData[1];
                    try {
                        // Parse cost, time, and distance
                        double cost = Double.parseDouble(edgeData[2].replace("$", "").trim());
                        double travelTime = Double.parseDouble(edgeData[3].replace("min", "").trim());

                        // Get source and target cities
                        CaptalCityNode source = graph.getCityByName(sourceName);
                        CaptalCityNode target = graph.getCityByName(targetName);

                        if (source != null && target != null) {
                            graph.addEdge(source, target, cost, travelTime, cost); // Pass the cost
                        } else {
                            System.err.println("City not found: " + sourceName + " or " + targetName);
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid numeric values in edge data: " + line);
                    }

                }
            }

        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }
        return graph;
    }
}
