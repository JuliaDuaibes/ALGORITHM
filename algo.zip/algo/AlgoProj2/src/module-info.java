module AlgoProj2 {
	requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
	
//	requires javafx.controls;
    requires javafx.fxml;

//    opens application to javafx.base;

	
	opens application to javafx.graphics, javafx.fxml, javafx.base;
}
