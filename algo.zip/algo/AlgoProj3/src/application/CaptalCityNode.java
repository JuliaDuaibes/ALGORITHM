package application;

import java.util.LinkedList;

public class CaptalCityNode {
    private String name;
    private double latitude;
    private double longitude;
    private LinkedList<Edge> edges;
    private double distance; // For Dijkstra
    private CaptalCityNode previous; // For Dijkstra

    public CaptalCityNode(String name, double latitude, double longitude) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.edges = new LinkedList<>();
        this.distance = Double.MAX_VALUE; // Initialize distance to "infinity"
        this.previous = null; // Initialize previous to null
    }

    public String getName() {
        return name;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public LinkedList<Edge> getEdges() {
        return edges;
    }

    public void addEdge(Edge edge) {
        this.edges.add(edge);
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public CaptalCityNode getPrevious() {
        return previous;
    }

    public void setPrevious(CaptalCityNode previous) {
        this.previous = previous;
    }

    @Override
    public String toString() {
        return name;
    }
}
