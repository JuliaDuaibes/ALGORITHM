package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Interface {
	private OnePlayer One = new OnePlayer();// one player Game Object
	private TwoPlayers Two = new TwoPlayers();// Two player's Game Object

	// Open Cover page
	public void openCoverStage(Stage primaryStage) {
		// Stage title
		primaryStage.setTitle("Optimal Coin Strategy Game");

		// Title Label
		Label titleLabel = new Label("Optimal Coin Strategy Game");
		titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 32)); // Clean, modern font with larger size
		titleLabel.setTextFill(Color.web("#FFFFFF")); // White for better contrast
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.8), 15, 0, 0, 5);"); // More prominent
																									// shadow effect

		String buttonStyle = "-fx-background-color: linear-gradient(to right, #09D1C7, #15919B,#09D1C7); -fx-text-fill: white; -fx-background-radius: 30;";
		String buttonHoverStyle = "-fx-background-color: linear-gradient(to right,  #15919B, #09D1C7,#15919B); -fx-text-fill: white; -fx-background-radius: 30;";
		// One Player Button
		Button onePlayerButton = new Button("1 Player");
		onePlayerButton.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 24)); // Larger font for buttons
		onePlayerButton.setPrefWidth(300); // Bigger button size
		onePlayerButton.setStyle(buttonStyle);
		onePlayerButton.setEffect(new DropShadow(8, Color.BLACK)); // Subtle shadow effect for depth
		onePlayerButton.setOnMouseEntered(e -> onePlayerButton.setStyle(buttonHoverStyle));
		onePlayerButton.setOnMouseExited(e -> onePlayerButton.setStyle(buttonStyle));
		onePlayerButton.setOnAction(e -> startOnePlayerMode(primaryStage));

		// Two Player Button
		Button twoPlayerButton = new Button("2 Players");
		twoPlayerButton.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 24)); // Uniform button font size
		twoPlayerButton.setPrefWidth(300);
		twoPlayerButton.setStyle(buttonStyle); // Same style as onePlayerButton
		twoPlayerButton.setEffect(new DropShadow(8, Color.BLACK)); // Same subtle shadow for consistency
		twoPlayerButton.setOnMouseEntered(e -> twoPlayerButton.setStyle(buttonHoverStyle));
		twoPlayerButton.setOnMouseExited(e -> twoPlayerButton.setStyle(buttonStyle));
		twoPlayerButton.setOnAction(e -> startTwoPlayerMode(primaryStage));

		// Arrange buttons in a vertical layout with spacing
		VBox buttonBox = new VBox(20, onePlayerButton, twoPlayerButton);
		buttonBox.setAlignment(Pos.CENTER);

		// Root layout with title and buttons
		VBox root = new VBox(40, titleLabel, buttonBox);
		root.setAlignment(Pos.CENTER);

		// Add padding and smooth transitions
		root.setPadding(new Insets(50));
		root.setSpacing(30);
		root.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");

		// Smooth transition effect when scene is shown
		Scene scene = new Scene(root, 600, 500); // Larger window for a more spacious feel
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	// to start 1 player Game
	private void startOnePlayerMode(Stage primaryStage) {
		openOnePlayerCoinInputStage(primaryStage);
	}

	// to start 2 player's Game
	private void startTwoPlayerMode(Stage primaryStage) {
		InsertNames(primaryStage);

	}

	// Input Stage (1 player)
	private void openOnePlayerCoinInputStage(Stage primaryStage) {
		Stage coinInputStage = new Stage();
		coinInputStage.setTitle("Select Coin Input Method");

		// Instruction label
		Label instructionLabel = new Label("Choose a method to enter the coins:");
		instructionLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 20));
		instructionLabel.setTextFill(Color.web("#EAEAEA"));
		instructionLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		// Label and TextField for manual input
		Label inputL = new Label("Type an even number of coins:");
		inputL.setFont(Font.font("Roboto", FontWeight.BOLD, 16));
		inputL.setTextFill(Color.WHITE);
		TextField inputF = new TextField();
		inputF.setPromptText("Enter number of coins...");

		// Buttons for selecting coin input method
		Button manualEntryButton = styleButton("Enter Coins Manually");
		manualEntryButton.setFont(Font.font("Roboto", FontWeight.SEMI_BOLD, 14));
		Button loadFileButton = styleButton("Load Coins from File");
		loadFileButton.setFont(Font.font("Roboto", FontWeight.SEMI_BOLD, 14));
		Button randomGenerationButton = styleButton("Generate Random Coins");
		randomGenerationButton.setFont(Font.font("Roboto", FontWeight.SEMI_BOLD, 14));

		// Button actions
		manualEntryButton.setOnAction(e -> {
			int numberOfCoins = parseNumberOfCoins(inputF);
			if (numberOfCoins > 0 && numberOfCoins % 2 == 0) {
				openManualEntryOne(numberOfCoins); // Proceed to manual entry stage
			} else {
				showAlert("Error", "Please enter a even number of coins.");
			}
		});
		loadFileButton.setOnAction(e -> {
			int numberOfCoins = parseNumberOfCoins(inputF);
			if (numberOfCoins > 0 && numberOfCoins % 2 == 0) {
				openFileChooserOne(numberOfCoins); // Proceed to file selection
			} else {
				showAlert("Error", "Please enter a even number of coins.");
			}
		});
		randomGenerationButton.setOnAction(e -> {
			int numberOfCoins = parseNumberOfCoins(inputF);
			if (numberOfCoins > 0 && numberOfCoins % 2 == 0) {
				OnePlayerRangeInputStage(numberOfCoins);// to enter a range
			} else {
				showAlert("Error", "Please enter a even number of coins.");
			}
		});
		// Layout for input label and field
		HBox inputBox = new HBox(10);
		inputBox.setAlignment(Pos.CENTER);
		inputBox.getChildren().addAll(inputL, inputF);

		// Create a File Menu with proper labels and actions
		Menu Menu = new Menu("Game Options");

		// Exit Option with Confirmation
		MenuItem exitItem = new MenuItem("Exit Game");
		exitItem.setOnAction(e -> {
			// Confirmation of exit Page
			Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit the game?",
					ButtonType.YES, ButtonType.NO);
			exitConfirmation.showAndWait().ifPresent(response -> {
				if (response == ButtonType.YES) {
					coinInputStage.close(); // Exit action
				}
			});
		});
		Menu.getItems().add(exitItem);
		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().add(Menu);

		BorderPane pane = new BorderPane();

		// VBox for the options
		VBox optionsBox = new VBox(15, manualEntryButton, loadFileButton, randomGenerationButton);
		optionsBox.setAlignment(Pos.CENTER);

		// Root layout setup
		VBox root = new VBox(20, inputBox, instructionLabel, optionsBox);// Root layout setup

		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));
		root.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");

		pane.setTop(menuBar);
		pane.setCenter(root);
		// Scene setup
		Scene scene = new Scene(pane, 600, 500);
		coinInputStage.setScene(scene);
		coinInputStage.show();
	}

	// way's to get the coins (file,manually,Randomly)
	private void openFileChooserOne(int numCoins) {// get from file
		One.OnePlayerFileChooserStage(numCoins);
	}

	private void openRandomEntityStageOne(int numCoins, int min, int max) {// get randomly
		One.OnePlayerRandomStage(numCoins, min, max);
	}

	private void openManualEntryOne(int numCoins) {// get manually
		One.OnePlayerManualStage(numCoins);
	}

	// Input Stage (2 player's)
	private void openTwoPlayerCoinInputStage(Stage primaryStage, String name1, String name2) {
		Stage coinInputStage = new Stage();
		coinInputStage.setTitle("Select Coin Input Method");
		// Instruction label
		Label instructionLabel = new Label("Choose a method to enter the coins:");
		instructionLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 20));
		instructionLabel.setTextFill(Color.web("#EAEAEA"));
		instructionLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");
		// Label and TextField for manual input
		Label inputL = new Label("Type an even number of coins:");
		inputL.setFont(Font.font("Roboto", FontWeight.BOLD, 16));
		inputL.setTextFill(Color.WHITE);
		TextField inputF = new TextField();
		inputF.setPromptText("Enter number of coins...");
		// Buttons for selecting coin input method
		Button manualEntryButton = styleButton("Enter Coins Manually");
		manualEntryButton.setFont(Font.font("Roboto", FontWeight.SEMI_BOLD, 14));
		Button loadFileButton = styleButton("Load Coins from File");
		loadFileButton.setFont(Font.font("Roboto", FontWeight.SEMI_BOLD, 14));
		Button randomGenerationButton = styleButton("Generate Random Coins");
		randomGenerationButton.setFont(Font.font("Roboto", FontWeight.SEMI_BOLD, 14));

		// Button actions
		manualEntryButton.setOnAction(e -> {
			int numberOfCoins = parseNumberOfCoins(inputF);
			if (numberOfCoins > 0 && numberOfCoins % 2 == 0) {
				openManualEntryTwo(numberOfCoins, name1, name2); // Proceed to manual entry stage
			} else {
				showAlert("Error", "Please enter a even number of coins.");
			}
		});

		loadFileButton.setOnAction(e -> {
			int numberOfCoins = parseNumberOfCoins(inputF);
			if (numberOfCoins > 0 && numberOfCoins % 2 == 0) {
				openFileChooser(numberOfCoins, name1, name2); // Proceed to file selection
			} else {
				showAlert("Error", "Please enter a even number of coins.");
			}
		});

		randomGenerationButton.setOnAction(e -> {
			int numberOfCoins = parseNumberOfCoins(inputF);
			if (numberOfCoins > 0 && numberOfCoins % 2 == 0) {
				TwoPlayerRangeInputStage(numberOfCoins, name1, name2);// get the range
				// Proceed to random generation
			} else {
				showAlert("Error", "Please enter a even number of coins.");
			}
		});
		// Layout for input label and field
		HBox inputBox = new HBox(10);
		inputBox.setAlignment(Pos.CENTER);
		inputBox.getChildren().addAll(inputL, inputF);

		// Create a File Menu with proper labels and actions
		Menu Menu = new Menu("Game Options");

		// Exit Option with Confirmation
		MenuItem exitItem = new MenuItem("Exit Game");
		exitItem.setOnAction(e -> {
			// Confirmation to exit the Game
			Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit the game?",
					ButtonType.YES, ButtonType.NO);
			exitConfirmation.showAndWait().ifPresent(response -> {
				if (response == ButtonType.YES) {
					coinInputStage.close(); // Exit action
				}
			});
		});
		Menu.getItems().add(exitItem);
		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().add(Menu);

		BorderPane pane = new BorderPane();

		// VBox for the options
		VBox optionsBox = new VBox(15, manualEntryButton, loadFileButton, randomGenerationButton);
		optionsBox.setAlignment(Pos.CENTER);

		// Root layout setup
		VBox root = new VBox(20, inputBox, instructionLabel, optionsBox);// Root layout setup
		// style root
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));

		pane.setCenter(root);
		pane.setTop(menuBar);
		root.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		// Scene setup
		Scene scene = new Scene(pane, 600, 500);
		coinInputStage.setScene(scene);
		coinInputStage.show();
	}

	// way's to get the coins (file,manually,Randomly)
	private void openFileChooser(int numberOfCoins, String name1, String name2) {// get from file
		Two.TwoPlayersFileStage(numberOfCoins, name1, name2);
	}

	private void openRandomEntityStage(int numberOfCoins, String name1, String name2, int min, int max) {// get randomly
		Two.TwoPlayersRandomStage(numberOfCoins, name1, name2, min, max);

	}

	private void openManualEntryTwo(int numberOfCoins, String name1, String name2) {// get manually
		Two.TwoPlayersManualStage(numberOfCoins, name1, name2);

	}

	// style the buttons
	private Button styleButton(String text) {
		String buttonStyle = "-fx-background-color: linear-gradient(to right, #09D1C7, #15919B,#09D1C7); -fx-text-fill: white; -fx-background-radius: 30;";
		String buttonHoverStyle = "-fx-background-color: linear-gradient(to right,  #15919B, #09D1C7,#15919B); -fx-text-fill: white; -fx-background-radius: 30;";
		// One Player Button
		Button button = new Button(text);
		button.setStyle(buttonStyle);
		button.setOnMouseEntered(e -> button.setStyle(buttonStyle));
		button.setOnMouseExited(e -> button.setStyle(buttonHoverStyle));
		return button;
	}

	// Method to parse the number of coins from inputF
	private int parseNumberOfCoins(TextField inputF) {
		try {
			String input = inputF.getText().trim();
			return Integer.parseInt(input); // Parse the input as an integer
		} catch (NumberFormatException e) {
			return -1; // Return -1 if the input is not a valid number
		}
	}

	private void InsertNames(Stage primaryStage) {
		Stage inputStage = new Stage();
		inputStage.setTitle("Fill Names");

		// Labels and TextFields for Player Names
		Label player1NameLabel = new Label("Player One Name:");
		Label player2NameLabel = new Label("Player Two Name:");
		TextField nameField1 = new TextField();
		nameField1.setPromptText("Your Name");
		TextField nameField2 = new TextField();
		nameField2.setPromptText("Your Name");

		player1NameLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 12)); // Use a modern font and larger size
		player1NameLabel.setTextFill(Color.web("#EAEAEA")); // Softer white for a professional feel
		player1NameLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		player2NameLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 12)); // Use a modern font and larger size
		player2NameLabel.setTextFill(Color.web("#EAEAEA")); // Softer white for a professional feel
		player2NameLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		// Start Button with initial disabled state
		Button startGameButton = styleButton("Start");
		startGameButton.setDisable(true);

		// GridPane setup
		GridPane grid = new GridPane();
		grid.setVgap(10);
		grid.setHgap(10);
		grid.setAlignment(Pos.CENTER);

		// Add components to GridPane
		grid.add(player1NameLabel, 0, 0);
		grid.add(nameField1, 1, 0);
		grid.add(player2NameLabel, 0, 1);
		grid.add(nameField2, 1, 1);
		grid.add(startGameButton, 1, 2);

		// Listener to enable "Start" button when both fields are not empty
		nameField1.textProperty().addListener((observable, oldValue, newValue) -> startGameButton
				.setDisable(nameField1.getText().isEmpty() || nameField2.getText().isEmpty()));
		nameField2.textProperty().addListener((observable, oldValue, newValue) -> startGameButton
				.setDisable(nameField1.getText().isEmpty() || nameField2.getText().isEmpty()));
		startGameButton.setOnAction(
				e -> openTwoPlayerCoinInputStage(primaryStage, nameField1.getText(), nameField2.getText()));
		inputStage.close();
		grid.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		// Set up the scene and stage
		Scene scene = new Scene(grid, 400, 250);
		inputStage.setScene(scene);
		inputStage.show();
	}

	public void OnePlayerRangeInputStage(int numCoins) {
		BorderPane pane = new BorderPane();
		Stage stage = new Stage();
		stage.setTitle("Enter Range"); // Stage Title
		// Title Label
		Label titleLabel = new Label("Enter Range Values");
		titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 18));
		titleLabel.setTextFill(Color.WHITE);
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		// Instructions
		Label instructionLabel = new Label("Please enter a valid minimum and maximum range:");
		instructionLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
		instructionLabel.setTextFill(Color.WHITE);

		// Minimum Range Input
		Label minLabel = new Label("Minimum:");
		minLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 12));
		minLabel.setTextFill(Color.WHITE);

		TextField minField = new TextField();
		minField.setPromptText("Enter minimum value");
		minField.setPrefWidth(100);

		// Maximum Range Input
		Label maxLabel = new Label("Maximum:");
		maxLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 12));
		maxLabel.setTextFill(Color.WHITE);

		TextField maxField = new TextField();
		maxField.setPromptText("Enter maximum value");
		maxField.setPrefWidth(100);

		// HBox for Min and Max Inputs
		HBox inputBox = new HBox(15, minLabel, minField, maxLabel, maxField);
		inputBox.setAlignment(Pos.CENTER);

		// Button to Confirm, Initially Disabled
		Button confirmButton = styleButton("Confirm");
		confirmButton.setDisable(true); // Disabled until valid input

		// Enable confirm button only when fields are valid
		minField.textProperty().addListener((observable, oldValue, newValue) -> {
			confirmButton.setDisable(!isRangeValid(minField, maxField));
		});

		maxField.textProperty().addListener((observable, oldValue, newValue) -> {
			confirmButton.setDisable(!isRangeValid(minField, maxField));
		});
		// Confirm Button Action
		confirmButton.setOnAction(e -> {
			try {
				// Parse the minimum and maximum values
				int min = Integer.parseInt(minField.getText().trim());
				int max = Integer.parseInt(maxField.getText().trim());

				// Validate that both numbers are positive
				if (min <= 0 || max <= 0) {
					throw new IllegalArgumentException("Both minimum and maximum must be positive numbers.");
				}

				// Ensure that the minimum is not greater than the maximum
				if (min > max) {
					showAlert("Error", "Please enter valid numbers for the range.");
					throw new IllegalArgumentException("Minimum cannot be greater than maximum.");
				}

				// Open the next stage
				openRandomEntityStageOne(numCoins, min, max);

				stage.close();
			} catch (NumberFormatException ex) {
				// Handle non-numeric inputs
				showAlert("Error", "Please enter valid numbers for the range.");
			} catch (IllegalArgumentException ex) {
				// Handle validation errors
				showAlert("Error", ex.getMessage());
			}
		});

		// Root Layout
		VBox root = new VBox(20, titleLabel, instructionLabel, inputBox, confirmButton);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));
		pane.setCenter(root);
		pane.setStyle("-fx-background-color: #0C6478;");

		// Scene Setup
		Scene scene = new Scene(pane, 450, 250);
		stage.setScene(scene);
		stage.show();
	}

	public void TwoPlayerRangeInputStage(int numCoins, String Name1, String Name2) {
		BorderPane pane = new BorderPane();
		Stage stage = new Stage();
		stage.setTitle("Enter Range"); // Stage Title
		// Title Label
		Label titleLabel = new Label("Enter Range Values");
		titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 18));
		titleLabel.setTextFill(Color.WHITE);
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		// Instructions
		Label instructionLabel = new Label("Please enter a valid minimum and maximum range:");
		instructionLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
		instructionLabel.setTextFill(Color.WHITE);

		// Minimum Range Input
		Label minLabel = new Label("Minimum:");
		minLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 12));
		minLabel.setTextFill(Color.WHITE);

		TextField minField = new TextField();
		minField.setPromptText("Enter minimum value");
		minField.setPrefWidth(100);

		// Maximum Range Input
		Label maxLabel = new Label("Maximum:");
		maxLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 12));
		maxLabel.setTextFill(Color.WHITE);

		TextField maxField = new TextField();
		maxField.setPromptText("Enter maximum value");
		maxField.setPrefWidth(100);

		// HBox for Min and Max Inputs
		HBox inputBox = new HBox(15, minLabel, minField, maxLabel, maxField);
		inputBox.setAlignment(Pos.CENTER);

		// Button to Confirm, Initially Disabled
		Button confirmButton = styleButton("Confirm");
		confirmButton.setDisable(true); // Disabled until valid input

		// Enable confirm button only when fields are valid
		minField.textProperty().addListener((observable, oldValue, newValue) -> {
			confirmButton.setDisable(!isRangeValid(minField, maxField));
		});

		maxField.textProperty().addListener((observable, oldValue, newValue) -> {
			confirmButton.setDisable(!isRangeValid(minField, maxField));
		});
		// Confirm Button Action
		confirmButton.setOnAction(e -> {
			try {
				// Parse the minimum and maximum values
				int min = Integer.parseInt(minField.getText().trim());
				int max = Integer.parseInt(maxField.getText().trim());

				// Validate that both numbers are positive
				if (min <= 0 || max <= 0) {
					throw new IllegalArgumentException("Both minimum and maximum must be positive numbers.");
				}

				// Ensure that the minimum is not greater than the maximum
				if (min > max) {
					showAlert("Error", "Please enter valid numbers for the range.");
					throw new IllegalArgumentException("Minimum cannot be greater than maximum.");
				}

				// Open the next stage
				openRandomEntityStage(numCoins, Name1, Name2, min, max);
				stage.close();
			} catch (NumberFormatException ex) {
				// Handle non-numeric inputs
				showAlert("Error", "Please enter valid numbers for the range.");
			} catch (IllegalArgumentException ex) {
				// Handle validation errors
				showAlert("Error", ex.getMessage());
			}
		});

		// Root Layout
		VBox root = new VBox(20, titleLabel, instructionLabel, inputBox, confirmButton);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));
		pane.setCenter(root);
		pane.setStyle("-fx-background-color: #0C6478;");

		// Scene Setup
		Scene scene = new Scene(pane, 450, 250);
		stage.setScene(scene);
		stage.show();
	}

	// Helper Method to Validate Range Inputs
	private boolean isRangeValid(TextField minField, TextField maxField) {
		try {
			int min = Integer.parseInt(minField.getText().trim());
			int max = Integer.parseInt(maxField.getText().trim());
			return min <= max; // Valid if min <= max
		} catch (NumberFormatException ex) {
			return false; // Invalid if not numeric
		}
	}

	// Helper Method to Show Alerts

	private void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle(title);
		alert.setContentText(message);
		alert.showAndWait();
	}

}
