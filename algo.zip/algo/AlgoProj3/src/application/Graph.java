package application;

import java.util.LinkedList;

public class Graph {
    private LinkedList<CaptalCityNode> cities;

    public Graph() {
        this.cities = new LinkedList<>();
    }

    public LinkedList<Edge> getEdges() {
        LinkedList<Edge> allEdges = new LinkedList<>();
        for (CaptalCityNode city : cities) {
            allEdges.addAll(city.getEdges());
        }
        return allEdges;
    }

    public LinkedList<Edge> getAdjacentEdges(CaptalCityNode city) {
        return city.getEdges();
    }

    public LinkedList<CaptalCityNode> getCities() {
        return cities;
    }

    public CaptalCityNode getCityByName(String name) {
        for (CaptalCityNode city : cities) {
            if (city.getName().equalsIgnoreCase(name)) {
                return city;
            }
        }
        return null;
    }

    public void addCity(CaptalCityNode city) {
        if (city == null) {
            System.err.println("Error: Cannot add a null city!");
            return;
        }
        cities.add(city);
    }

    public void addEdge(CaptalCityNode source, CaptalCityNode target, double distance, double travelTime, double cost) {
        if (source == null || target == null) {
            System.err.println("Error: Source or target city is null!");
            return;
        }
        // Create the edge with cost
        Edge edge = new Edge(source, target, distance, travelTime, cost);
        source.addEdge(edge);

        Edge reverseEdge = new Edge(target, source, distance, travelTime, cost);
        target.addEdge(reverseEdge);
    }



}
