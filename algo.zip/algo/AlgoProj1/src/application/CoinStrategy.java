package application;

import javafx.scene.control.Label;

public class CoinStrategy {

	// Optimal Game Strategy (1 player)
	public int OptimalselectionStrategy(int[] coins, boolean[] selectedCoins) {
		int n = coins.length;
		int[][] dp = new int[n][n];
		
		fillDpTable(coins, dp);
		
		if (n == 1) {
			dp[0][0] = coins[0];
		} else if (n == 2) {
			dp[0][0] = Math.max(coins[0], coins[1]);
		} else {

//		fillDpTable(coins, dp);
			// Now, we need to make the move based on the dp table and selectedCoins
			int i = 0, j = n - 1;
			// Find the first and last unselected coins
			while (i < n && selectedCoins[i])// (meaning the coin has been selected)
				i++;
			while (j >= 0 && selectedCoins[j])
				j--;
			// If no more coins are available, return -1
			if (i > j)
				return -1;

			int x = (i + 2 <= j) ? dp[i + 2][j] : 0;// player 1 select i
			int y = (i + 1 <= j - 1) ? dp[i + 1][j - 1] : 0;
			int z = (i <= j - 2) ? dp[i][j - 2] : 0;

			// future scores
			int futureScoreIfPickLeft = coins[i] + Math.min((x), (y));
			int futureScoreIfPickRight = coins[j] + Math.min((z), (y));

			if (futureScoreIfPickRight > futureScoreIfPickLeft
					|| (futureScoreIfPickRight == futureScoreIfPickLeft && coins[j] > coins[i])) {
				selectedCoins[j] = true;
				return j;
			} else {
				selectedCoins[i] = true;
				return i;
			}
		
		}
		return -1;
	}

	// Fill the DP table with optimal values for sub-problems
	public void fillDpTable(int[] coins, int[][] GD) {
		int n = coins.length;

		for (int K = 0; K < n; K++) { // Iterate over all possible gaps between indices
			for (int i = 0, j = K; j < n; i++, j++) { // Iterate over the starting index i and ending index j
				int x = (i + 2 <= j) ? GD[i + 2][j] : 0;
				int y = (i + 1 <= j - 1) ? GD[i + 1][j - 1] : 0;
				int z = (i <= j - 2) ? GD[i][j - 2] : 0;

				// Calculate the optimal choice (max value) for this subproblem
				GD[i][j] = Math.max(coins[i] + Math.min(x, y), coins[j] + Math.min(y, z));
			}
		}
	}

	// Generates a random array of coins for the game
	public int[] generateRandomCoins(int numCoins, int min, int max) {
		int[] coins = new int[numCoins];
		for (int i = 0; i < numCoins; i++) {
			coins[i] = (int) (Math.random() * (max - min + 1)) + min; // Corrected range formula
		}
		return coins;
	}

	// Two players Game
	public int TwoPlayerGame(int[] coins, boolean[] selectedCoins, String Index) {
		int n = coins.length;
		int i = 0, j = n - 1;

		while (i < n && selectedCoins[i])// (meaning the coin has been selected)
			i++;
		while (j >= 0 && selectedCoins[j])
			j--;
		if (Index.equalsIgnoreCase("F")) {
			selectedCoins[i] = true;
			return i;
		} else if (Index.equalsIgnoreCase("L")) {
			selectedCoins[j] = true;
			return j;
		}
		return -1;

	}

	// Append the DP table to the output for display
	public void appendDpTable(int[][] GD, StringBuilder output, int[] coins) {
		fillDpTable(coins, GD);
		for (int row = 0; row < GD.length; row++) {
			for (int col = 0; col < GD[row].length; col++) {
				output.append(GD[row][col]).append("\t");
			}
			output.append("\n");
		}
	}

	// Check if all coins selected!
	public boolean allCoinsSelected(boolean[] selectedCoins) {
		for (boolean selected : selectedCoins) {
			if (!selected)
				return false;
		}
		return true;
	}

	// update coins after selections
	public void updateCoinsDisplay(int[] coins, boolean[] selectedCoins, Label coinsLabel) {
		StringBuilder coinsDisplay = new StringBuilder("Coins: ");
		for (int i = 0; i < coins.length; i++) {
			if (!selectedCoins[i]) {
				coinsDisplay.append(coins[i]).append(" ");
			}
		}
		coinsLabel.setText(coinsDisplay.toString().trim());
	}

	// Convert array to stringBuilder
	public String arrayToString(int[] arr) {
		StringBuilder sb = new StringBuilder();
		for (int num : arr) {
			sb.append(num).append(" ");
		}
		return sb.toString().trim();
	}

}
