package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class OnePlayer {
	private CoinStrategy strategy = new CoinStrategy(); // Strategy for generating moves and DP table
	private int player1Score = 0, player2Score = 0;// Store the score of players
	private int[] Randomcoins;// store the random coins
	private int[] Manualcoins;// Store the manual Coins
	private int[] Filecoins;// Store the manual Coins
	private boolean[] selectedCoins;// mark a selected coins
	// sequence of selected coins for each player
	private StringBuilder computerSelectedCoinsSequence = new StringBuilder();
	private StringBuilder playerSelectedCoinsSequence = new StringBuilder();
	boolean isGameStarted = false;// mark if game started

	// Random coins GAME
	public void OnePlayerRandomStage(int numCoins, int min, int max) {
		int number = numCoins;// number of coins
		Randomcoins = strategy.generateRandomCoins(numCoins, min, max);// get random coins
		int[][] dp = new int[number][number];// for table
		selectedCoins = new boolean[numCoins];// mark the selected coins

		// Create the main BorderPane
		BorderPane pane = new BorderPane();
		Stage randomStage = new Stage();
		randomStage.setTitle("Optimal Coin Selection Game");

		// Title label
		Label titleLabel = new Label("Optimal Strategy Game");
		titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 30));
		titleLabel.setTextFill(Color.WHITE);
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");
		// Display generated coins
		Label coinsLabel = new Label("Coins: " + strategy.arrayToString(Randomcoins));
		coinsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
		coinsLabel.setTextFill(Color.WHITE);
		coinsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		// Create control buttons
		Button startButton = styleButton("Start Game");
		Button resultsButton = new Button("Results of Game");
		Button TableButton = new Button(" Show dp table");
		resultsButton.setDisable(true);
		TableButton.setDisable(true);

		// Labels for player and computer progress
		Label playerSelectedCoinLabel = new Label("Selected coins: ");
		Label playerExpectedResultLabel = new Label("Expected result: ");
		Label computerSelectedCoinLabel = new Label("Selected coins: ");
		Label computerExpectedResultLabel = new Label("Expected result: ");

		// Player layout
		Label playerLabel = new Label("Player");
		playerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
		playerLabel.setTextFill(Color.GREEN);
		VBox playerBox = new VBox(10, playerLabel, playerSelectedCoinLabel, playerExpectedResultLabel);
		playerBox.setAlignment(Pos.CENTER);
		playerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

		// Computer layout
		Label computerLabel = new Label("Computer");
		computerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
		computerLabel.setTextFill(Color.GREEN);
		VBox computerBox = new VBox(10, computerLabel, computerSelectedCoinLabel, computerExpectedResultLabel);
		computerBox.setAlignment(Pos.CENTER);
		computerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

		// FlowPane to display coin states
		FlowPane coinsFlowPane = new FlowPane();
		coinsFlowPane.setHgap(10);
		coinsFlowPane.setAlignment(Pos.CENTER);

		// Display coins (disabled initially)
		updateCoinsDisplayInFlowPane(Randomcoins, selectedCoins, coinsFlowPane, true, isGameStarted);

		// selected coins for each player in current GAME
		computerSelectedCoinsSequence = new StringBuilder();
		playerSelectedCoinsSequence = new StringBuilder();

		// Game logic for coin selection
		startButton.setOnAction(e -> {
			isGameStarted = true; // Game is now started
			startButton.setDisable(true); // Disable the Start Game button
			updateCoinsDisplayInFlowPane(Randomcoins, selectedCoins, coinsFlowPane, true, isGameStarted); // to Enable
																											// coin
																											// buttons
			// store scores
			player1Score = 0;
			player2Score = 0;

			new Thread(() -> {
				while (!strategy.allCoinsSelected(selectedCoins)) {// to check if all coins selected
					// Computer turn
					Platform.runLater(() -> {
						int selectedCoinIndex = strategy.OptimalselectionStrategy(Randomcoins, selectedCoins);
						if (selectedCoinIndex != -1) {
							selectedCoins[selectedCoinIndex] = true;
							player2Score += Randomcoins[selectedCoinIndex];

							if (computerSelectedCoinsSequence.length() > 0) {
								computerSelectedCoinsSequence.append(",");
							}
							computerSelectedCoinsSequence.append(Randomcoins[selectedCoinIndex]);
							computerSelectedCoinLabel.setText("Selected coins: " + computerSelectedCoinsSequence);
							computerExpectedResultLabel.setText("Expected result: " + player2Score);
							Platform.runLater(() -> {
								updateCoinsDisplayInFlowPane(Randomcoins, selectedCoins, coinsFlowPane, false,
										isGameStarted); // Disable
								// buttons
							});
						}
					});

					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}

					// Player turn
					Platform.runLater(() -> {
						int selectedCoinIndex = strategy.OptimalselectionStrategy(Randomcoins, selectedCoins);
						if (selectedCoinIndex != -1) {
							selectedCoins[selectedCoinIndex] = true;
							player1Score += Randomcoins[selectedCoinIndex];

							if (playerSelectedCoinsSequence.length() > 0) {
								playerSelectedCoinsSequence.append(",");
							}
							playerSelectedCoinsSequence.append(Randomcoins[selectedCoinIndex]);

							playerSelectedCoinLabel.setText("Selected coins: " + playerSelectedCoinsSequence);
							playerExpectedResultLabel.setText("Expected result: " + player1Score);

							Platform.runLater(() -> {
								updateCoinsDisplayInFlowPane(Randomcoins, selectedCoins, coinsFlowPane, false,
										isGameStarted); // Disable
								// buttons
							});
						}
					});

					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}
				}
				Platform.runLater(() -> {
					resultsButton.setDisable(false);
					resultsButton.setOnAction(e1 -> endGame(dp, Randomcoins));
					TableButton.setDisable(false);
					TableButton.setOnAction(e1 -> ShowTable(dp, Randomcoins));
				});
			}).start();
		});
		// Layout setup
		GridPane grid = new GridPane();
		grid.add(startButton, 5, 0);
		grid.add(playerBox, 1, 1);
		grid.add(computerBox, 6, 1);
		grid.add(resultsButton, 5, 5);
		grid.add(TableButton, 5, 6);
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);

		VBox root = new VBox(20, titleLabel, coinsLabel, coinsFlowPane, grid);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));

		// Menu setup
		Menu fileMenu = new Menu("Game Options");
		MenuItem exitItem = new MenuItem("Exit Game");
		MenuItem playAgainItem = new MenuItem("Play again");
		exitItem.setOnAction(e -> {
			Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit the game?",
					ButtonType.YES, ButtonType.NO);
			exitConfirmation.showAndWait().ifPresent(response -> {
				if (response == ButtonType.YES) {
					randomStage.close();
				}
			});
		});
		playAgainItem.setOnAction(e -> {

			resetGame(playerSelectedCoinsSequence, computerSelectedCoinsSequence, playerSelectedCoinLabel,
					playerExpectedResultLabel, computerSelectedCoinLabel, computerExpectedResultLabel, startButton,
					resultsButton, TableButton, numCoins, coinsLabel, startButton, null, true, false, min, max);
			coinsLabel.setText("Coins :" + strategy.arrayToString(Randomcoins));
			Platform.runLater(() -> {
				updateCoinsDisplayInFlowPane(Randomcoins, selectedCoins, coinsFlowPane, false, false); // Disable
																										// buttons
			});
			startButton.setDisable(false);
		});

		fileMenu.getItems().addAll(new SeparatorMenuItem(), exitItem, playAgainItem);
		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().add(fileMenu);

		pane.setTop(menuBar);
		pane.setCenter(root);
		pane.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");

		// Scene setup
		Scene scene = new Scene(pane, 600, 500);
		randomStage.setScene(scene);
		randomStage.show();
	}

	// enter coins manually
	public void OnePlayerManualStage(int numCoins) {
		BorderPane pane = new BorderPane();
		Stage stage = new Stage();
		stage.setTitle("Enter Coins");// stage Title

		// Title label
		Label titleLabel = new Label("Enter Coin Values");
		titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 18));
		titleLabel.setTextFill(Color.WHITE);// Use a modern font and larger size
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		// Instructions
		Label instructionLabel = new Label("Please enter " + numCoins + " coin values:");
		instructionLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
		instructionLabel.setTextFill(Color.WHITE);

		// Create TextFields for each coin
		HBox coinInputBox = new HBox(10); // Space between TextFields
		coinInputBox.setAlignment(Pos.CENTER);
		TextField[] coinFields = new TextField[numCoins];

		for (int i = 0; i < numCoins; i++) {// field to store coins number according numCoins
			TextField coinField = new TextField();
			coinField.setPromptText("Coin " + (i + 1));// next
			coinField.setPrefWidth(60); // Set width for consistency
			coinFields[i] = coinField;
			coinInputBox.getChildren().add(coinField);// added field
		}

		// Button to start the game, initially disabled
		Button startButton = styleButton("Start Game");
		startButton.setDisable(true); // Disabled until all fields are filled

		// Enable start button only when all TextFields have valid input
		for (TextField coinField : coinFields) {
			coinField.textProperty().addListener((observable, oldValue, newValue) -> {
				startButton.setDisable(!areFilled(coinFields));
			});
		}

		startButton.setOnAction(e -> {
			// Read entered values and start the game
			Manualcoins = new int[numCoins];
			try {
				for (int i = 0; i < numCoins; i++) {
					int value = Integer.parseInt(coinFields[i].getText().trim());
					if (value <= 0) {
						throw new NumberFormatException(); // Treat non-positive numbers as invalid
					}
					Manualcoins[i] = value;
				}
			} catch (NumberFormatException ex) {
				showAlert("Exception", "You should enter only positive numbers. Please try again.");
				return;
			}
			stage.close(); // Close this window and proceed to the game

			ManualStage(numCoins, Manualcoins); // open stage to start actual game
		});

		// Root layout
		VBox root = new VBox(15, titleLabel, instructionLabel, coinInputBox, startButton);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));

		pane.setCenter(root);
		pane.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		Scene scene = new Scene(pane, 400, 250);
		stage.setScene(scene);
		stage.show();
	}

	private void ManualStage(int numCoins, int[] coinValues) {// interface for game
		Stage manualStage = new Stage();
		int number = numCoins;
		int[][] dp = new int[number][number];// Calculate DP table based on the coins array
		selectedCoins = new boolean[numCoins]; // Track selected coins

		BorderPane paneb = new BorderPane();
		manualStage.setTitle("Optimal Coin Selection Game");

		// Title label
		Label TitleLabel = new Label("Optimal Strategy Game");
		TitleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 30)); // Use a modern font and larger size
		TitleLabel.setTextFill(Color.WHITE); // Softer white for a professional feel
		TitleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");
		// Display generated coins
		Label coinsLabel = new Label("Coins: " + strategy.arrayToString(coinValues));
		coinsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
		coinsLabel.setTextFill(Color.WHITE);
		coinsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");
		// Buttons for game controls
		Button StartGameButton = styleButton(" Start Game ");
		Button ResultButton = new Button("Results of Game");
		Button TableButton = new Button(" Show dp Table ");

		// Labels for tracking selected coin and result for each player
		Label playerSelectedCoinLabel = new Label("Selected coin: ");
		Label playerExpectedResultLabel = new Label("Expected result: ");
		Label computerSelectedCoinLabel = new Label("Selected coin: ");
		Label computerExpectedResultLabel = new Label("Expected result: ");

		// Player layout
		Label playerLabel = new Label("Player");
		playerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
		playerLabel.setTextFill(Color.GREEN);
		VBox playerBox = new VBox(10, playerLabel, playerSelectedCoinLabel, playerExpectedResultLabel);
		playerBox.setAlignment(Pos.CENTER);
		playerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

		// Computer layout
		Label computerLabel = new Label("Computer");
		computerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
		computerLabel.setTextFill(Color.GREEN);
		VBox computerBox = new VBox(10, computerLabel, computerSelectedCoinLabel, computerExpectedResultLabel);
		computerBox.setAlignment(Pos.CENTER);
		computerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

		TableButton.setDisable(true);
		ResultButton.setDisable(true);

		// FlowPane to display coin states
		FlowPane coinsFlowPane = new FlowPane();
		coinsFlowPane.setHgap(10);
		coinsFlowPane.setAlignment(Pos.CENTER);

		// Display coins (disabled initially)
		updateCoinsDisplayInFlowPane(Manualcoins, selectedCoins, coinsFlowPane, true, isGameStarted);

		// selected coins for each player in current GAME
		computerSelectedCoinsSequence = new StringBuilder();
		playerSelectedCoinsSequence = new StringBuilder();

		// Game logic for coin selection
		StartGameButton.setOnAction(e -> {
			isGameStarted = true; // Game is now started
			StartGameButton.setDisable(true); // Disable the Start Game button
			updateCoinsDisplayInFlowPane(Manualcoins, selectedCoins, coinsFlowPane, true, isGameStarted); // to Enable
																											// coin
																											// buttons
			// store scores
			player1Score = 0;
			player2Score = 0;

			new Thread(() -> {
				while (!strategy.allCoinsSelected(selectedCoins)) {// to check if all coins selected
					// Computer turn
					Platform.runLater(() -> {
						int selectedCoinIndex = strategy.OptimalselectionStrategy(Manualcoins, selectedCoins);
						if (selectedCoinIndex != -1) {
							selectedCoins[selectedCoinIndex] = true;
							player2Score += Manualcoins[selectedCoinIndex];

							if (computerSelectedCoinsSequence.length() > 0) {
								computerSelectedCoinsSequence.append(",");
							}
							computerSelectedCoinsSequence.append(Manualcoins[selectedCoinIndex]);
							computerSelectedCoinLabel.setText("Selected coins: " + computerSelectedCoinsSequence);
							computerExpectedResultLabel.setText("Expected result: " + player2Score);
							Platform.runLater(() -> {
								updateCoinsDisplayInFlowPane(Manualcoins, selectedCoins, coinsFlowPane, false,
										isGameStarted); // Disable
								// buttons
							});
						}
					});

					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}

					// Player turn
					Platform.runLater(() -> {
						int selectedCoinIndex = strategy.OptimalselectionStrategy(Manualcoins, selectedCoins);
						if (selectedCoinIndex != -1) {
							selectedCoins[selectedCoinIndex] = true;
							player1Score += Manualcoins[selectedCoinIndex];

							if (playerSelectedCoinsSequence.length() > 0) {
								playerSelectedCoinsSequence.append(",");
							}
							playerSelectedCoinsSequence.append(Manualcoins[selectedCoinIndex]);

							playerSelectedCoinLabel.setText("Selected coins: " + playerSelectedCoinsSequence);
							playerExpectedResultLabel.setText("Expected result: " + player1Score);
							Platform.runLater(() -> {
								updateCoinsDisplayInFlowPane(Manualcoins, selectedCoins, coinsFlowPane, false,
										isGameStarted); // Disable
								// buttons
							});
						}
					});

					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}
				}
				Platform.runLater(() -> {
					ResultButton.setDisable(false);
					ResultButton.setOnAction(e1 -> endGame(dp, Manualcoins));
					TableButton.setDisable(false);
					TableButton.setOnAction(e1 -> ShowTable(dp, Manualcoins));
				});
			}).start();
		});
		// Layout setup
		GridPane grid = new GridPane();
		grid.add(StartGameButton, 5, 0);
		grid.add(playerBox, 1, 1);
		grid.add(computerBox, 6, 1);
		grid.add(ResultButton, 5, 5);
		grid.add(TableButton, 5, 6);
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);

		VBox root = new VBox(20, TitleLabel, coinsLabel, coinsFlowPane, grid);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));

		// Menu setup
		Menu fileMenu = new Menu("Game Options");
		MenuItem exitItem = new MenuItem("Exit Game");
		MenuItem playAgainItem = new MenuItem("Play again");
		exitItem.setOnAction(e -> {
			Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit the game?",
					ButtonType.YES, ButtonType.NO);
			exitConfirmation.showAndWait().ifPresent(response -> {
				if (response == ButtonType.YES) {
					manualStage.close();
				}
			});
		});
		playAgainItem.setOnAction(e -> {
			manualStage.close();
			// Reopen the input stage if new inputs are required
			OnePlayerManualStage(numCoins);
			// Reset the game with the resetGame method

			resetGame(playerSelectedCoinsSequence, computerSelectedCoinsSequence, playerSelectedCoinLabel,
					playerExpectedResultLabel, computerSelectedCoinLabel, computerExpectedResultLabel, StartGameButton,
					ResultButton, TableButton, numCoins, coinsLabel, StartGameButton, Manualcoins, false, false, 0, 0);
			coinsLabel.setText("Coins :" + strategy.arrayToString(Manualcoins));
			Platform.runLater(() -> {
				updateCoinsDisplayInFlowPane(Manualcoins, selectedCoins, coinsFlowPane, false, false); // Disable
																										// buttons
			});
			StartGameButton.setDisable(false);
		});

		fileMenu.getItems().addAll(new SeparatorMenuItem(), exitItem, playAgainItem);
		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().add(fileMenu);

		paneb.setTop(menuBar);
		paneb.setCenter(root);
		paneb.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		// Scene setup
		Scene scene = new Scene(paneb, 600, 500);
		manualStage.setScene(scene);
		manualStage.show();
	}

	// Helper method to check if all TextFields are filled
	private boolean areFilled(TextField[] fields) {
		for (TextField field : fields) {
			if (field.getText().trim().isEmpty()) {
				return false;
			}
		}
		return true;
	}

	public void OnePlayerFileChooserStage(int numCoins) {//
		Stage primaryStage = new Stage();
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open Coin File");
		fileChooser.setInitialDirectory(new File("c:\\"));
		File file = fileChooser.showOpenDialog(primaryStage);
		String coinsStr[] = new String[numCoins];

		if (file != null) {
			try (Scanner scanner = new Scanner(file)) {
				StringBuilder fileContent = new StringBuilder();
				while (scanner.hasNextLine()) {
					fileContent.append(scanner.nextLine()).append(",");
				}

				for (int i = 0; i < numCoins; i++) {
					coinsStr = fileContent.toString().split(",");

				}
				// Initialize the game stage with loaded coins
				Filecoins = new int[numCoins];
				int index = 0; // Tracks the current position in the `coinsStr` array
				int filledCount = 0; // Tracks how many valid positive numbers have been added to `Filecoins`

				while (filledCount < numCoins) {
					// Cycle through `coinsStr` repeatedly if needed
					String coinStr = coinsStr[index % coinsStr.length].trim();
					index++; // Move to the next number (wraps around due to `%`)

					try {
						int value = Integer.parseInt(coinStr); // Parse the value
						if (value > 0) { // Add only positive numbers
							Filecoins[filledCount++] = value;
						}
						// Skip negative numbers and zero automatically
					} catch (NumberFormatException ex) {
						// Skip invalid entries (non-numeric values)
						System.err.println("Invalid entry skipped: " + coinStr);
					}
				}
				FileStage(primaryStage, numCoins);

			} catch (FileNotFoundException e) {
				showAlert("ErrorFile", "File not found.");
			} catch (NumberFormatException e) {
				showAlert("ErrorFile", "Invalid file format. Please ensure the file contains only integers.");
			}
		}
	}

	private void FileStage(Stage primaryStage, int numCoins) {
		int number = numCoins;
		int[][] dp = new int[number][number];// Calculate DP table based on the coins array
		selectedCoins = new boolean[number];
		BorderPane pane = new BorderPane();
		Stage fileStage = new Stage();
		fileStage.setTitle("Optimal Coin Selection Game");

		Label titleLabel = new Label("Optimal Strategy Game");
		titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 30)); // Use a modern font and larger size
		titleLabel.setTextFill(Color.WHITE); // Softer white for a professional feel
		titleLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		Label coinsLabel = new Label("Coins: " + strategy.arrayToString(Filecoins));
		coinsLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
		coinsLabel.setTextFill(Color.WHITE);
		coinsLabel.setStyle("-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 10, 0, 0, 5);");

		Button startButton = styleButton("Start Game");
		Button playerPickButton = new Button("Player Pick Coin");
		Button computerPickButton = new Button("Computer Pick Coin");
		Button resultsButton = new Button("Results of Game");
		Button TableButton = new Button(" Show dp table ");

		Label playerSelectedCoinLabel = new Label("Selected coin: ");
		Label playerExpectedResultLabel = new Label("Expected result: ");
		Label computerSelectedCoinLabel = new Label("Selected coin: ");
		Label computerExpectedResultLabel = new Label("Expected result: ");

		computerPickButton.setDisable(true);
		playerPickButton.setDisable(true);
		resultsButton.setDisable(true);
		TableButton.setDisable(true);
		// Player layout
		Label playerLabel = new Label("Player");
		playerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
		playerLabel.setTextFill(Color.GREEN);
		VBox playerBox = new VBox(10, playerLabel, playerSelectedCoinLabel, playerExpectedResultLabel);
		playerBox.setAlignment(Pos.CENTER);
		playerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

		// Computer layout
		Label computerLabel = new Label("Computer");
		computerLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
		computerLabel.setTextFill(Color.GREEN);
		VBox computerBox = new VBox(10, computerLabel, computerSelectedCoinLabel, computerExpectedResultLabel);
		computerBox.setAlignment(Pos.CENTER);
		computerBox.setStyle("-fx-border-color: #2C3E50; -fx-padding: 10; -fx-background-color: #ecf0f1;");

		TableButton.setDisable(true);
		resultsButton.setDisable(true);

		// FlowPane to display coin states
		FlowPane coinsFlowPane = new FlowPane();
		coinsFlowPane.setHgap(10);
		coinsFlowPane.setAlignment(Pos.CENTER);

		// Display coins (disabled initially)
		updateCoinsDisplayInFlowPane(Filecoins, selectedCoins, coinsFlowPane, true, isGameStarted);

		// selected coins for each player in current GAME
		computerSelectedCoinsSequence = new StringBuilder();
		playerSelectedCoinsSequence = new StringBuilder();

		// Game logic for coin selection
		startButton.setOnAction(e -> {
			isGameStarted = true; // Game is now started
			startButton.setDisable(true); // Disable the Start Game button
			updateCoinsDisplayInFlowPane(Filecoins, selectedCoins, coinsFlowPane, true, isGameStarted); // to Enable
																										// coin
																										// buttons
			// store scores
			player1Score = 0;
			player2Score = 0;

			new Thread(() -> {
				while (!strategy.allCoinsSelected(selectedCoins)) {// to check if all coins selected
					// Computer turn
					Platform.runLater(() -> {
						int selectedCoinIndex = strategy.OptimalselectionStrategy(Filecoins, selectedCoins);
						if (selectedCoinIndex != -1) {
							selectedCoins[selectedCoinIndex] = true;
							player2Score += Filecoins[selectedCoinIndex];

							if (computerSelectedCoinsSequence.length() > 0) {
								computerSelectedCoinsSequence.append(",");
							}
							computerSelectedCoinsSequence.append(Filecoins[selectedCoinIndex]);
							computerSelectedCoinLabel.setText("Selected coins: " + computerSelectedCoinsSequence);
							computerExpectedResultLabel.setText("Expected result: " + player2Score);
							Platform.runLater(() -> {
								updateCoinsDisplayInFlowPane(Filecoins, selectedCoins, coinsFlowPane, false,
										isGameStarted); // Disable
								// buttons
							});
						}
					});

					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}

					// Player turn
					Platform.runLater(() -> {
						int selectedCoinIndex = strategy.OptimalselectionStrategy(Filecoins, selectedCoins);
						if (selectedCoinIndex != -1) {
							selectedCoins[selectedCoinIndex] = true;
							player1Score += Filecoins[selectedCoinIndex];

							if (playerSelectedCoinsSequence.length() > 0) {
								playerSelectedCoinsSequence.append(",");
							}
							playerSelectedCoinsSequence.append(Filecoins[selectedCoinIndex]);

							playerSelectedCoinLabel.setText("Selected coins: " + playerSelectedCoinsSequence);
							playerExpectedResultLabel.setText("Expected result: " + player1Score);
							Platform.runLater(() -> {
								updateCoinsDisplayInFlowPane(Filecoins, selectedCoins, coinsFlowPane, false,
										isGameStarted); // Disable
								// buttons
							});
						}
					});

					try {
						Thread.sleep(1000);
					} catch (InterruptedException ex) {
						ex.printStackTrace();
					}
				}
				Platform.runLater(() -> {
					resultsButton.setDisable(false);
					resultsButton.setOnAction(e1 -> endGame(dp, Filecoins));
					TableButton.setDisable(false);
					TableButton.setOnAction(e1 -> ShowTable(dp, Filecoins));
				});
			}).start();
		});
		// Layout setup
		GridPane grid = new GridPane();
		grid.add(startButton, 5, 0);
		grid.add(playerBox, 1, 1);
		grid.add(computerBox, 6, 1);
		grid.add(resultsButton, 5, 5);
		grid.add(TableButton, 5, 6);
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);

		VBox root = new VBox(20, titleLabel, coinsLabel, coinsFlowPane, grid);
		root.setAlignment(Pos.CENTER);
		root.setPadding(new Insets(20));

		// Menu setup
		Menu fileMenu = new Menu("Game Options");
		MenuItem exitItem = new MenuItem("Exit Game");
		MenuItem playAgainItem = new MenuItem("Play again");
		exitItem.setOnAction(e -> {
			Alert exitConfirmation = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit the game?",
					ButtonType.YES, ButtonType.NO);
			exitConfirmation.showAndWait().ifPresent(response -> {
				if (response == ButtonType.YES) {
					fileStage.close();
				}
			});
		});
		playAgainItem.setOnAction(e -> {
			fileStage.close();
			// Reset the game with the resetGame method
			resetGame(playerSelectedCoinsSequence, computerSelectedCoinsSequence, playerSelectedCoinLabel,
					playerExpectedResultLabel, computerSelectedCoinLabel, computerExpectedResultLabel, startButton,
					resultsButton, TableButton, numCoins, coinsLabel, startButton, null, false, true, 0, 0);
			coinsLabel.setText("Coins :" + strategy.arrayToString(Filecoins));
			Platform.runLater(() -> {
				updateCoinsDisplayInFlowPane(Filecoins, selectedCoins, coinsFlowPane, false, false); // Disable
																										// buttons
			});
			startButton.setDisable(false);
		});

		fileMenu.getItems().addAll(new SeparatorMenuItem(), exitItem, playAgainItem);
		MenuBar menuBar = new MenuBar();
		menuBar.getMenus().add(fileMenu);

		pane.setCenter(root);
		pane.setTop(menuBar);
		pane.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		Scene scene = new Scene(pane, 600, 500);
		fileStage.setScene(scene);
		fileStage.show();
	}

	private void endGame(int[][] table, int[] coins) {
		// Create a new Stage for the result window
		Stage stage = new Stage();
		StringBuilder results = new StringBuilder();

		// Determine the winner based on final scores
		String winner;
		if (player1Score > player2Score) {
			winner = "Player wins!";

		} else if (player1Score < player2Score) {
			winner = "Computer wins!";
		} else {
			winner = "It's a tie!";

		}

		// Building result string
		results.append("\nGame Ended!\n").append("Final Score - Player: ").append(player1Score).append(" ,Computer: ")
				.append(player2Score).append("\n\nSelected Coins:\n").append("Computer: ")
				.append(computerSelectedCoinsSequence).append("\nPlayer: ").append(playerSelectedCoinsSequence)
				.append("\n\n").append(winner).append("\n");

		// Create Labels for each section
		Label titleLabel = new Label("Game Over!");
		titleLabel.setFont(new Font("Arial", 24));
		titleLabel.setStyle("-fx-font-weight: bold;");
		titleLabel.setTextFill(Color.WHITE);

		Label finalScoreLabel = new Label("Final Score - Player: " + player1Score + " , Computer: " + player2Score);
		finalScoreLabel.setFont(new Font("Arial", 18));
		finalScoreLabel.setTextFill(Color.WHITE);

		Label coinsLabel = new Label("Selected Coins:");
		coinsLabel.setFont(new Font("Arial", 18));
		coinsLabel.setTextFill(Color.WHITE);

		Label computerCoinsLabel = new Label("Computer: " + computerSelectedCoinsSequence);
		computerCoinsLabel.setFont(new Font("Arial", 16));
		computerCoinsLabel.setTextFill(Color.WHITE);

		Label playerCoinsLabel = new Label("Player: " + playerSelectedCoinsSequence);
		playerCoinsLabel.setFont(new Font("Arial", 16));
		playerCoinsLabel.setTextFill(Color.WHITE);

		Label winnerLabel = new Label(winner);
		winnerLabel.setFont(new Font("Arial", 18));
		winnerLabel.setStyle("-fx-font-weight: bold;");
		winnerLabel.setTextFill(Color.WHITE);

		// Add padding and spacing for better UI
		VBox layout = new VBox(15);
		layout.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		layout.setPrefWidth(400);

		// Adding labels to VBox layout
		layout.getChildren().addAll(titleLabel, finalScoreLabel, coinsLabel, computerCoinsLabel, playerCoinsLabel,
				winnerLabel);

		// Create a Button to allow the user to close or restart the game
		Button closeButton = new Button("Close");
		closeButton.setOnAction(e -> stage.close()); // Closes the stage when clicked

		// Adding the Close button to the VBox
		layout.getChildren().add(closeButton);

		// Set alignment to center all elements
		layout.setAlignment(Pos.CENTER);

		// Create a Scene with the layout
		Scene resultScene = new Scene(layout, 450, 350);

		// Set the scene to the stage and show it
		stage.setScene(resultScene);
		stage.setTitle("Game Results");
		stage.show();
	}

	private void ShowTable(int[][] table, int[] coins) {
		// Initialize the StringBuilder to store the table content
		StringBuilder Table = new StringBuilder();

		// Fill and append the table content
		strategy.fillDpTable(coins, table);
		strategy.appendDpTable(table, Table, coins);

		// Create a new Stage to show the table
		Stage tableStage = new Stage();

		// Title Label for the table view
		Label titleLabel = new Label("Final Table");
		titleLabel.setFont(new Font("Arial", 24));
		titleLabel.setStyle("-fx-font-weight: bold;");
		titleLabel.setTextFill(Color.WHITE);

		// Create a TextArea to display the table content, set it to non-editable
		TextArea tableTextArea = new TextArea(Table.toString());
		tableTextArea.setWrapText(true);
		tableTextArea.setEditable(false); // Make sure it's non-editable
		tableTextArea.setStyle("-fx-font-family: Arial; -fx-font-size: 14px;");

		// Wrap the TextArea in a ScrollPane to enable scrolling for larger tables
		ScrollPane scrollPane = new ScrollPane(tableTextArea);
		scrollPane.setFitToWidth(true); // Ensures text fits within the width of the pane

		// Create a button to close the table view
		Button closeButton = new Button("Close");
		closeButton.setOnAction(e -> tableStage.close());

		// Create a VBox layout to hold the title, scrollable table, and close button
		VBox layout = new VBox(20);
		layout.setStyle("-fx-background-color: linear-gradient(to bottom, #0C6478, #213A58);");
		layout.setAlignment(Pos.CENTER);
		layout.getChildren().addAll(titleLabel, scrollPane, closeButton);

		// Create a Scene with the layout
		Scene tableScene = new Scene(layout, 500, 400);

		// Set the scene for the table stage and show it
		tableStage.setScene(tableScene);
		tableStage.setTitle("Dynamic Table View");
		tableStage.show();
	}

	private void resetGame(StringBuilder playerSelectedCoinsSequence, StringBuilder computerSelectedCoinsSequence,
			Label playerSelectedCoinLabel, Label playerExpectedResultLabel, Label computerSelectedCoinLabel,
			Label computerExpectedResultLabel, Button startButton, Button playerPickButton, Button computerPickButton,
			int numCoins, Label coinsLabel, Button resultButton, int[] manualCoins, boolean isRandomMode,
			boolean IsFile, int min, int max) {

		// Reset scores
		player1Score = 0;
		player2Score = 0;

		// Set up coins based on game mode
		if (isRandomMode) {
			// Generate a new random sequence of coins

			Randomcoins = strategy.generateRandomCoins(numCoins, min, max);
			strategy.updateCoinsDisplay(Randomcoins, selectedCoins, coinsLabel);
		} else if (IsFile) {
			// Use coins from file if fileStage is provided in manual mode
			OnePlayerFileChooserStage(numCoins);
			strategy.updateCoinsDisplay(Filecoins, selectedCoins, coinsLabel);
		} else {
			// Use manually entered coins for manual mode without fileStage
			strategy.updateCoinsDisplay(Manualcoins, selectedCoins, coinsLabel);
		}

		// Reset selected coins array to mark all coins as unselected
		selectedCoins = new boolean[numCoins];

		// Clear the selected coins sequence for both player and computer
		playerSelectedCoinsSequence.setLength(0);
		computerSelectedCoinsSequence.setLength(0);

		// Update the UI labels to clear previous selections and results
		playerSelectedCoinLabel.setText("Selected coins: ");
		playerExpectedResultLabel.setText("Expected result: ");
		computerSelectedCoinLabel.setText("Selected coins: ");
		computerExpectedResultLabel.setText("Expected result: ");

		// Enable the start button and disable the pick buttons initially
		startButton.setDisable(false);
		playerPickButton.setDisable(true);
		computerPickButton.setDisable(true);
		resultButton.setDisable(true);
	}

	private void updateCoinsDisplayInFlowPane(int[] coins, boolean[] selectedCoins, FlowPane coinsFlowPane,
			boolean isPlayerTurn, boolean isGameStarted) {
		coinsFlowPane.getChildren().clear(); // Clear previous items
		for (int i = 0; i < coins.length; i++) {
			Button coinButton = new Button(String.valueOf(coins[i]));

			// Disable buttons if the game hasn't started or if the coin is already selected
			coinButton.setDisable(!isGameStarted || selectedCoins[i]);

			// Set the initial style
			if (selectedCoins[i]) {
				coinButton.setStyle("-fx-background-color: #B0BEC5; -fx-text-fill: black; -fx-font-weight: bold;"); // Gray
																													// for
																													// selected
																													// coins
			} else {
				coinButton.setStyle("-fx-background-color: #FFFFFF; -fx-text-fill: black; -fx-font-weight: bold;"); // White
																													// for
																													// not
																													// selected
			}

			int coinIndex = i;
			coinButton.setOnAction(e -> {
				if (isGameStarted && !selectedCoins[coinIndex]) { // Ensure game has started and coin is not selected
					selectedCoins[coinIndex] = true; // Mark coin as selected
					coinButton.setDisable(true); // Disable the button after selection

					// Change button color based on who picked it
					if (isPlayerTurn) {
						coinButton.setStyle(
								"-fx-background-color: #FF4C4C; -fx-text-fill: white; -fx-font-weight: bold;"); // Red
																												// for
																												// player
						// pick
					} else {
						coinButton.setStyle(
								"-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;"); // Green
																												// for
																												// computer
																												// pick
					}

					// Update display for next turn
					updateCoinsDisplayInFlowPane(coins, selectedCoins, coinsFlowPane, !isPlayerTurn, true); // Toggle
																											// turn
				}
			});

			coinsFlowPane.getChildren().add(coinButton);
		}
	}

	// style the buttons
	private Button styleButton(String text) {
		String buttonStyle = "-fx-background-color: linear-gradient(to right, #09D1C7, #15919B,#09D1C7); -fx-text-fill: white; -fx-background-radius: 30;";
		String buttonHoverStyle = "-fx-background-color: linear-gradient(to right,  #15919B, #09D1C7,#15919B); -fx-text-fill: white; -fx-background-radius: 30;";
		// One Player Button
		Button button = new Button(text);
		button.setStyle(buttonStyle);
		button.setOnMouseEntered(e -> button.setStyle(buttonStyle));
		button.setOnMouseExited(e -> button.setStyle(buttonHoverStyle));
		return button;
	}

	private void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle(title);
		alert.setContentText(message);
		alert.showAndWait();
	}

}