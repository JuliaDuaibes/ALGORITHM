package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.util.ArrayList;

public class MapVisualization {
	private final Pane mapPane;
	private final String mapImagePath;
	private ImageView mapView;
	private final ArrayList<Line> drawnPaths = new ArrayList<>();
	private final ArrayList<Circle> cityMarkers = new ArrayList<>();

	public MapVisualization(String mapImagePath) {
		this.mapImagePath = mapImagePath;
		this.mapPane = new Pane();
	}

	public Pane getMapPane() {
		return mapPane;
	}

	public void initializeMap() {
		try {
			Image mapImage = new Image(mapImagePath);
			mapView = new ImageView(mapImage);

			mapView.setPreserveRatio(true);
			mapView.setFitWidth(900);
			mapView.setFitHeight(450);

			mapView.setX(0);
			mapView.setY(0);

			mapPane.getChildren().add(mapView);
		} catch (Exception e) {
			System.err.println("Error loading map image: " + e.getMessage());
		}
	}

	public void highlightCities(ArrayList<CaptalCityNode> cities) {
		for (CaptalCityNode city : cities) {
			// Convert latitude and longitude to pixel coordinates
			double[] pixelCoords = convertToPixel(city.getLatitude(), city.getLongitude());

			// Ensure the coordinates are within the bounds of the map view
			if (pixelCoords[0] >= 0 && pixelCoords[0] <= mapView.getFitWidth() && pixelCoords[1] >= 0
					&& pixelCoords[1] <= mapView.getFitHeight()) {

				// Create a circle to represent the city
				Circle cityMarker = new Circle(pixelCoords[0], pixelCoords[1], 5, Color.WHITE);

				// Add a text label for the city
				Text cityName = new Text(city.getName());
				cityName.setFont(Font.font("Arial", FontWeight.BOLD, 12)); // Adjust font size
				cityName.setFill(Color.WHITE); // Change text color to white for visibility

				// Position the label slightly offset from the city marker
				cityName.setX(pixelCoords[0] + 10); // Adjust horizontal offset
				cityName.setY(pixelCoords[1] - 10); // Adjust vertical offset

				// Prevent overlapping labels by adding wrapping width
				cityName.setWrappingWidth(80); // Adjust as needed for longer city names

				// Add the marker and label to the map pane
				cityMarkers.add(cityMarker);
				mapPane.getChildren().addAll(cityMarker, cityName);
			} else {
				System.err.println("City " + city.getName() + " is out of bounds and cannot be displayed.");
			}
		}
	}

	public void drawPath(ArrayList<CaptalCityNode> path) {
		CaptalCityNode previous = null;
		for (CaptalCityNode city : path) {
			double[] currentCoords = convertToPixel(city.getLatitude(), city.getLongitude());

			if (previous != null) {
				double[] previousCoords = convertToPixel(previous.getLatitude(), previous.getLongitude());
				Line line = new Line(previousCoords[0], previousCoords[1], currentCoords[0], currentCoords[1]);
				line.setStroke(Color.BLUE);
				line.setStrokeWidth(2);
				drawnPaths.add(line);
				mapPane.getChildren().add(line);
			}
			previous = city;
		}
	}

	public void clearMap() {
		mapPane.getChildren().removeAll(drawnPaths);
		drawnPaths.clear();
		mapPane.getChildren().removeAll(cityMarkers);
		cityMarkers.clear();
	}

	private double[] convertToPixel(double latitude, double longitude) {
		double mapWidth = mapView.getFitWidth();
		double mapHeight = mapView.getFitHeight();

		// Map bounds (adjust based on the specific map image used)
		double minLongitude = -180.0;
		double maxLongitude = 180.0;
		double minLatitude = -90.0;
		double maxLatitude = 90.0;

		// Convert longitude to x-coordinate
		double x = (longitude - minLongitude) / (maxLongitude - minLongitude) * mapWidth;

		// Convert latitude to y-coordinate (invert because image y-axis goes down)
		double y = (maxLatitude - latitude) / (maxLatitude - minLatitude) * mapHeight;

		return new double[] { x, y };
	}

}