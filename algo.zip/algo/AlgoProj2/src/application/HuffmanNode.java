package application;

public class HuffmanNode {
    private int frequency;
    private byte character;
    private HuffmanNode left;
    private HuffmanNode right;

    public HuffmanNode(byte character, int frequency) {
        this.character = character;
        this.frequency = frequency;
    }

    public HuffmanNode(int frequency, HuffmanNode left, HuffmanNode right) {
        this.frequency = frequency;
        this.left = left;
        this.right = right;
    }

    public int getFrequency() {
        return frequency;
    }

    public byte getCharacter() {
        return character;
    }

    public HuffmanNode getLeft() {
        return left;
    }

    public HuffmanNode getRight() {
        return right;
    }

    public boolean isLeaf() {
        return left == null && right == null;
    }
}
