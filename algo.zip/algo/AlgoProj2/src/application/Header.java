package application;

import java.io.*;

public class Header {
    private int[] frequencies;
    private String fileName;
    private String[] headerDetails;
    private String codeSequence;

    public Header(String[] headerDetails) {
        this.headerDetails = headerDetails;
    }

    public Header(String[] codes, int[] frequencies, String fileName) {
        this.frequencies = frequencies;
        this.fileName = fileName;
        this.codeSequence = generateCodeSequence(codes);
    }

    public static Header readHeader(InputStream input) throws IOException {
        DataInputStream dataInput = new DataInputStream(input);
        int[] frequencies = new int[256];
        for (int i = 0; i < 256; i++) {
            frequencies[i] = dataInput.readInt();
        }
        int nameLength = dataInput.readInt();
        byte[] nameBytes = new byte[nameLength];
        dataInput.readFully(nameBytes);
        String fileName = new String(nameBytes);

        
        String codeSequence = dataInput.readUTF();
        String[] codes = parseCodeSequence(codeSequence);

        return new Header(codes, frequencies, fileName);
    }

    private static String[] parseCodeSequence(String codeSequence) {
        String[] codes = new String[256];
        if (!codeSequence.isEmpty()) {
            String[] codeArray = codeSequence.split(" ");
            for (int i = 0; i < codeArray.length; i++) {
                codes[i] = codeArray[i];
            }
        }
        return codes;
    }

    public void writeHeader(OutputStream output) throws IOException {
        DataOutputStream dataOutput = new DataOutputStream(output);
        for (int freq : frequencies) {
            dataOutput.writeInt(freq);
        }
        byte[] nameBytes = fileName.getBytes();
        dataOutput.writeInt(nameBytes.length);
        dataOutput.write(nameBytes);
        dataOutput.writeUTF(codeSequence != null ? codeSequence : "");
    }

    public int[] getFrequencies() {
        return frequencies;
    }

    public String getFileName() {
        return fileName;
    }

    public String getCodeSequence() {
        return codeSequence;
    }

    public String getFileExtension() {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
            return fileName.substring(dotIndex + 1);
        }
        return "";
    }

    private String generateCodeSequence(String[] codes) {
        if (codes == null) {
            return "";
        }
        StringBuilder sequenceBuilder = new StringBuilder();
        for (String code : codes) {
            if (code != null) {
                sequenceBuilder.append(code).append(" ");
            }
        }
        return sequenceBuilder.toString().trim();
    }
}

