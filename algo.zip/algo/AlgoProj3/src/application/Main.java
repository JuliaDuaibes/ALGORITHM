package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			String fileName = "data.txt";
			Graph graph = DataLoader.loadFromFile(fileName);

			UserInterface userInterface = new UserInterface(graph);
			Scene scene = new Scene(userInterface.createRoot(), 1200, 600);
			primaryStage.setScene(scene);

			primaryStage.setTitle("World Map Path Finder - Enhanced");
			primaryStage.show();

		} catch (Exception e) {
			System.err.println("An error occurred while starting the application: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
