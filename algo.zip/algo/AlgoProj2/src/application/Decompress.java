package application;

import java.io.*;

public class Decompress {
    public File decompress(File inputFile) throws IOException {
        try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(inputFile))) {
           
            Header header = Header.readHeader(input);

            
            HuffmanTree huffmanTree = new HuffmanTree();
            huffmanTree.buildTreeFromFrequencies(header.getFrequencies());
            HuffmanNode root = huffmanTree.getRoot();

           
            String originalFileName = header.getFileName();
            String fileExtension = header.getFileExtension();
            String decompressedFileName = "decompressed" + originalFileName.replaceAll("\\.[^.]+$", "") + "." + fileExtension;

            File outputFile = new File(inputFile.getParent(), decompressedFileName);

            
            try (BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(outputFile))) {
                HuffmanNode currentNode = root;
                int bitBuffer;

                while ((bitBuffer = input.read()) != -1) {
                    for (int i = 7; i >= 0; i--) {
                        int bit = (bitBuffer >> i) & 1;
                        currentNode = (bit == 0) ? currentNode.getLeft() : currentNode.getRight();

                        if (currentNode.isLeaf()) {
                            output.write(currentNode.getCharacter());
                            currentNode = root;
                        }
                    }
                }
            }

//            System.out.println("Decompression completed: " + outputFile.getAbsolutePath());
            return outputFile;
        }
    }
}

