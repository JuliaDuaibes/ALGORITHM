package application;

import java.io.*;

public class Compress {
    private String[] huffmanCodes; // To store generated Huffman codes
    private int[] frequencies;    // To store frequencies of characters

    public void compress(File inputFile, File outputFile) throws IOException {
        // Step 1: Count frequencies of each byte in the input file
        frequencies = FrequencyCounter.countFrequencies(inputFile);

        // Step 2: Build the Huffman tree using a custom heap
        HuffmanTree huffmanTree = new HuffmanTree();
        huffmanTree.buildTreeFromFrequencies(frequencies);

        // Step 3: Generate Huffman codes for each byte
        huffmanCodes = new String[256];
        huffmanTree.generateCodes(huffmanCodes);

        // Step 4: Compress the file
        try (BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(outputFile));
             BufferedInputStream input = new BufferedInputStream(new FileInputStream(inputFile))) {
            // Write header (file metadata and Huffman tree)
            Header header = new Header(huffmanCodes, frequencies, inputFile.getName());
            header.writeHeader(output);

            // Write compressed data
            int bitBuffer = 0, bitCount = 0;
            int b;
            while ((b = input.read()) != -1) {
                String code = huffmanCodes[b & 0xFF];
                for (char bit : code.toCharArray()) {
                    bitBuffer = (bitBuffer << 1) | (bit - '0');
                    bitCount++;
                    if (bitCount == 8) {
                        output.write(bitBuffer);
                        bitBuffer = 0;
                        bitCount = 0;
                    }
                }
            }

            if (bitCount > 0) {
                output.write(bitBuffer << (8 - bitCount));
            }
        }
    }

    // Getter for Huffman codes
    public String[] getHuffmanCodes() {
        return huffmanCodes;
    }

    // Getter for frequencies
    public int[] getFrequencies() {
        return frequencies;
    }
}