package application;

import javafx.application.Application;
import javafx.stage.Stage;

public class mainClass extends Application {
    @Override
    public void start(Stage primaryStage) {
        myInterface myinterface = new myInterface();
        myinterface.CoverPage(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
