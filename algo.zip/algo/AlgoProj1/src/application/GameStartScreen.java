package application;

import javafx.application.Application;
import javafx.stage.Stage;

public class GameStartScreen extends Application {
	Interface interfaceOb = new Interface();// interFace of program

	@Override
	public void start(Stage primaryStage) {// cover Page
		interfaceOb.openCoverStage(primaryStage);
	}

	public static void main(String[] args) {
		launch(args);
	}
}