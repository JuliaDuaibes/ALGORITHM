package application;

import java.io.*;

public class FrequencyCounter {
    public static int[] countFrequencies(File file) throws IOException {
        int[] frequencies = new int[256];
        try (BufferedInputStream input = new BufferedInputStream(new FileInputStream(file))) {
            int b;
            while ((b = input.read()) != -1) {
                frequencies[b & 0xFF]++;
            }
        }
        return frequencies;
    }
}
