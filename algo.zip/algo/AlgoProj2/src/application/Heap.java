package application;

public class Heap {
	private HuffmanNode[] heap;
	private int size;

	public Heap(int capacity) {
		heap = new HuffmanNode[capacity];
		size = 0;
	}

	// Insert a node into the heap
	public void insert(HuffmanNode node) {
		if (size >= heap.length) {
			throw new IllegalStateException("Heap is full");
		}
		heap[size] = node;
		size++;
		heapifyUp(size - 1);
	}

	// Extract the minimum node from the heap
	public HuffmanNode extractMin() {
		if (size == 0) {
			return null; // Heap is empty
		}
		HuffmanNode min = heap[0];
		heap[0] = heap[size - 1];
		size--;
		heapifyDown(0);
		return min;
	}

	// Get the current size of the heap
	public int size() {
		return size;
	}

	// Heapify up to maintain the heap property after insertion
	private void heapifyUp(int index) {
		int parentIndex = (index - 1) / 2;
		while (index > 0 && heap[index].getFrequency() < heap[parentIndex].getFrequency()) {
			swap(index, parentIndex);
			index = parentIndex;
			parentIndex = (index - 1) / 2;
		}
	}

	// Heapify down to maintain the heap property after removal
	private void heapifyDown(int index) {
		int smallest = index;
		int leftChild = 2 * index + 1;
		int rightChild = 2 * index + 2;

		if (leftChild < size && heap[leftChild].getFrequency() < heap[smallest].getFrequency()) {
			smallest = leftChild;
		}
		if (rightChild < size && heap[rightChild].getFrequency()< heap[smallest].getFrequency()) {
			smallest = rightChild;
		}
		if (smallest != index) {
			swap(index, smallest);
			heapifyDown(smallest);
		}
	}

	// Swap two nodes in the heap
	private void swap(int i, int j) {
		HuffmanNode temp = heap[i];
		heap[i] = heap[j];
		heap[j] = temp;
	}
}
