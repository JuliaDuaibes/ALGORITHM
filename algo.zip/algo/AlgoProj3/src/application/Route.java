package application;

/**
 * Retrieves the path as a linked list of CaptalCityNode objects. The path
 * represents the sequence of cities (nodes) from the source to the target in
 * the calculated route.
 *
 * @return A LinkedList of CaptalCityNode objects representing the path.
 */
import java.util.LinkedList;

public class Route {
	private final LinkedList<CaptalCityNode> path;
	private final double totalDistance;
	private final double totalTime;
	private final double totalCost;

	public double getTotalDistance() {
		return totalDistance;
	}

	public double getTotalTime() {
		return totalTime;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public LinkedList<CaptalCityNode> getPath() {
		return path;
	}

	public Route(LinkedList<CaptalCityNode> path, double totalDistance, double totalTime, double totalCost) {
		this.path = path;
		this.totalDistance = totalDistance;
		this.totalTime = totalTime;
		this.totalCost = totalCost;
	}

	public String getPathString() {
		StringBuilder pathString = new StringBuilder();
		for (CaptalCityNode city : path) { // Assuming `path` is a LinkedList<CaptalCityNode>
			if (pathString.length() > 0) {
				pathString.append(" -> ");
			}
			pathString.append(city.getName());
		}
		return pathString.toString();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Path: ").append(path.toString()).append("\n");
		sb.append("Total Distance: ").append(String.format("%.2f km", totalDistance)).append("\n");
		sb.append("Total Time: ").append(String.format("%.2f min", totalTime)).append("\n");
		sb.append("Total Cost: ").append(String.format("$%.2f", totalCost)).append("\n");
		return sb.toString();
	}

}
