package application;

public class HuffmanTableRow {
    private char character;
    private int ascii;
    private int frequency;
    private String code;
    private int size; // Length of the Huffman code

    // Constructor
    public HuffmanTableRow(char character, int ascii, int frequency, String code) {
        this.character = character;
        this.ascii = ascii;
        this.frequency = frequency;
        this.code = code;
        this.size = (code != null) ? code.length() : 0; // Calculate size
    }

    // Getters
    public char getCharacter() {
        return character;
    }

    public int getAscii() {
        return ascii;
    }

    public int getFrequency() {
        return frequency;
    }

    public String getCode() {
        return code;
    }

    public int getSize() {
        return size;
    }

    // Setters
    public void setCharacter(char character) {
        this.character = character;
    }

    public void setAscii(int ascii) {
        this.ascii = ascii;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public void setCode(String code) {
        this.code = code;
        this.size = (code != null) ? code.length() : 0; // Update size whenever the code is set
    }

    // Optionally, a method to update the size explicitly if needed
    public void updateSize() {
        this.size = (code != null) ? code.length() : 0;
    }
}
//package application;
//
//public class HuffmanTableRow {
//    private char character; // Character represented in the Huffman table
//    private int ascii;      // ASCII value of the character
//    private int frequency;  // Frequency of the character in the file
//    private String code;    // Huffman code for the character
//    private int size;       // Length of the Huffman code
//
//    // Constructor
//    public HuffmanTableRow(char character, int ascii, int frequency, String code) {
//        this.character = character;
//        this.ascii = ascii;
//        this.frequency = frequency;
//        setCode(code); // Use setter to handle size calculation
//    }
//
//    // Getters
//    public char getCharacter() {
//        return character;
//    }
//
//    public int getAscii() {
//        return ascii;
//    }
//
//    public int getFrequency() {
//        return frequency;
//    }
//
//    public String getCode() {
//        return code;
//    }
//
//    public int getSize() {
//        return size;
//    }
//
//    // Setters
//    public void setCharacter(char character) {
//        this.character = character;
//    }
//
//    public void setAscii(int ascii) {
//        this.ascii = ascii;
//    }
//
//    public void setFrequency(int frequency) {
//        this.frequency = frequency;
//    }
//
//    public void setCode(String code) {
//        this.code = code;
//        // Update size whenever the code is set, defaulting to 0 if null or empty
//        this.size = (code != null) ? code.length() : 0;
//    }
//
//    // Optional: A method to display the row details for debugging
//    @Override
//    public String toString() {
//        return "HuffmanTableRow{" +
//                "character=" + character +
//                ", ascii=" + ascii +
//                ", frequency=" + frequency +
//                ", code='" + code + '\'' +
//                ", size=" + size +
//                '}';
//    }
//}
