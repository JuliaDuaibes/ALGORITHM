package application;
/**
 * The TableEntry class represents an entry in a table used for graph-based algorithms,
 * such as Dijkstra's shortest path algorithm. It stores three attributes:
 * - 'known': A boolean indicating if the shortest path to the node is finalized.
 * - 'dist': The current shortest distance to the node from a source node.
 * - 'path': The previous node in the shortest path to reconstruct the route.
 * This class is essential for tracking and updating the state of nodes during the algorithm.
 */

public class TableEntry {
    private boolean known;
    private double dist;
    private CaptalCityNode path;

    // Constructor
    public TableEntry() {
        this.known = false;
        this.dist = Double.MAX_VALUE;
        this.path = null;
    }

    // Getter and Setter for 'known'
    public boolean isKnown() {
        return known;
    }

    public void setKnown(boolean known) {
        this.known = known;
    }

    // Getter and Setter for 'dist'
    public double getDist() {
        return dist;
    }

    public void setDist(double dist) {
        this.dist = dist;
    }

    // Getter and Setter for 'path'
    public CaptalCityNode getPath() {
        return path;
    }

    public void setPath(CaptalCityNode path) {
        this.path = path;
    }
}
