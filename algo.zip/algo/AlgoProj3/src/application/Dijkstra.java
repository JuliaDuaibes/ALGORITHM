/**
 * The Dijkstra class provides methods to find the shortest, fastest, or cheapest path
 * between two cities in a graph using Dijkstra's algorithm.
 */
package application;

import java.util.LinkedList;

public class Dijkstra {

	/**
	 * Initializes the table used to track distances, known nodes, and paths. Sets
	 * the distance of the start node to 0 and others to infinity.
	 */
	private TableEntry[] initializeTable(CaptalCityNode start, Graph graph) {
		TableEntry[] table = new TableEntry[graph.getCities().size()];
		for (int i = 0; i < table.length; i++) {
			table[i] = new TableEntry();
		}
		// Set distance of the start node to 0
		table[graph.getCities().indexOf(start)].setDist(0.0);
		return table;
	}

	/**
	 * Core implementation of Dijkstra's algorithm. Finds the optimal path based on
	 * the given criteria (distance, time, or cost).
	 */
	private Route findPath(CaptalCityNode source, CaptalCityNode target, Graph graph, String criteria) {
		if (source == null || target == null || graph == null) {
			throw new IllegalArgumentException("Source, target, and graph cannot be null.");
		}

		// Step 1: Initialize the table
		TableEntry[] table = initializeTable(source, graph);

		while (true) {
			// Step 2: Find the smallest unknown distance vertex
			CaptalCityNode smallestUnknown = null;
			double smallestDist = Double.MAX_VALUE;

			for (int i = 0; i < table.length; i++) {
				CaptalCityNode city = graph.getCities().get(i);
				if (!table[i].isKnown() && table[i].getDist() < smallestDist) {
					smallestUnknown = city;
					smallestDist = table[i].getDist(); // Update smallest distance
				}
			}

			if (smallestUnknown == null) {
				break; // All vertices are known or unreachable
			}

			// Step 3: Mark the current node as known
			int currentIndex = graph.getCities().indexOf(smallestUnknown);
			TableEntry currentEntry = table[currentIndex];
			currentEntry.setKnown(true);

			// Step 4: Update distances for neighboring nodes
			for (Edge edge : graph.getAdjacentEdges(smallestUnknown)) {
				CaptalCityNode neighbor = edge.getTarget();
				int neighborIndex = graph.getCities().indexOf(neighbor);
				TableEntry neighborEntry = table[neighborIndex];

				if (!neighborEntry.isKnown()) {
					double newDist = currentEntry.getDist() + getWeight(edge, criteria);
					if (newDist < neighborEntry.getDist()) {
						neighborEntry.setDist(newDist);
						neighborEntry.setPath(smallestUnknown);
					}
				}
			}
		}

		// Step 5: Backtrack to construct the path
		LinkedList<CaptalCityNode> path = new LinkedList<>();
		CaptalCityNode step = target;

		while (step != null) {
			path.addFirst(step);
			step = table[graph.getCities().indexOf(step)].getPath();
		}

		if (path.size() == 0 || !path.get(0).equals(source)) {
			return null; // No valid path found
		}

		// Step 6: Calculate total distance, time, and cost
		double totalDistance = 0.0;
		double totalTime = 0.0;
		double totalCost = 0.0;

		for (int i = 0; i < path.size() - 1; i++) {
			CaptalCityNode from = path.get(i);
			CaptalCityNode to = path.get(i + 1);

			for (Edge edge : graph.getAdjacentEdges(from)) {
				if (edge.getTarget().equals(to)) {
					totalDistance += edge.getDistance();
					totalTime += edge.getTravelTime();
					totalCost += edge.getCost();
					break;
				}
			}
		}
		return new Route(path, totalDistance, totalTime, totalCost);
	}

	/**
	 * Returns the weight of an edge based on the given criteria (distance, time, or
	 * cost).
	 */
	private double getWeight(Edge edge, String criteria) {
		switch (criteria) {
		case "distance":
			return edge.getDistance();
		case "time":
			return edge.getTravelTime();
		case "cost":
			return edge.getCost();
		default:
			throw new IllegalArgumentException("Invalid criteria: " + criteria);
		}
	}

	/**
	 * Finds the shortest path based on distance.
	 */
	public Route findShortestPath(CaptalCityNode source, CaptalCityNode target, Graph graph) {
		return findPath(source, target, graph, "distance");
	}

	/**
	 * Finds the fastest path based on travel time.
	 */
	public Route findFastestPath(CaptalCityNode source, CaptalCityNode target, Graph graph) {
		return findPath(source, target, graph, "time");
	}

	/**
	 * Finds the cheapest path based on travel cost.
	 */
	public Route findCheapestPath(CaptalCityNode source, CaptalCityNode target, Graph graph) {
		return findPath(source, target, graph, "cost");
	}
}
