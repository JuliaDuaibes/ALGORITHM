package application;

import java.io.File;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class myInterface {

    private File selectedFile; // Stores the selected file
    private TableView<HuffmanTableRow> huffmanTable; // Table for Huffman details
    private VBox headerBox; // VBox for displaying header details
    private VBox statisticsBox; // VBox for displaying statistics
    private TabPane tabPane; // TabPane to hold the tabs

    public myInterface() {
        huffmanTable = initializeHuffmanTable(); // Initialize the Huffman table
    }

    public void CoverPage(Stage primaryStage) {
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));

        // Title
        Label title = new Label("Huffman File Compressor & Decompressor");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 32));
        title.setTextFill(Color.web("#FFFFFF")); // White title text
        BorderPane.setAlignment(title, Pos.CENTER);
        root.setTop(title);

        // Buttons in the center
        VBox centerContent = new VBox(15);
        centerContent.setAlignment(Pos.CENTER);

        Button compressButton = new Button("Compress");
        compressButton.setPrefWidth(150);
        compressButton.setStyle("-fx-background-color: #2C3E50; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        Button decompressButton = new Button("Decompress");
        decompressButton.setPrefWidth(150);
        decompressButton.setStyle("-fx-background-color: #2C3E50; -fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        centerContent.getChildren().addAll(compressButton, decompressButton);
        root.setCenter(centerContent);

        // Tabs for additional details
        tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setStyle("-fx-background-color: #2C3E50; -fx-tab-min-width: 120px; -fx-tab-max-width: 120px;");

        Tab statisticsTab = createStatisticsTab();
        Tab huffmanTableTab = createHuffmanTableTab();
        Tab headerTab = createHeaderTab();

        tabPane.getTabs().addAll(statisticsTab, huffmanTableTab, headerTab);
        root.setBottom(tabPane);

        // Event Handlers
        compressButton.setOnAction(e -> handleCompress(primaryStage));
        decompressButton.setOnAction(e -> handleDecompress(primaryStage));

        Scene scene = new Scene(root, 900, 600);
        root.setStyle("-fx-background-color: #34495E;"); // Slightly lighter than tabs
        primaryStage.setScene(scene);
        primaryStage.setTitle("Huffman File Compressor & Decompressor");
        primaryStage.show();
    }

    private void handleCompress(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select File to Compress");
        selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile == null) {
            showAlert("No File Selected", "Please select a file to compress.");
            return;
        }

        try {
            File compressedFile = new File(selectedFile.getParent(),
                    selectedFile.getName().replaceAll("\\.[^.]*$", ".huf"));

            Compress compress = new Compress();
            compress.compress(selectedFile, compressedFile);

            long originalSize = selectedFile.length();
            long compressedSize = compressedFile.length();
            double compressionRatio = 100.0 - ((compressedSize * 100.0) / originalSize);

            Header header = new Header(compress.getHuffmanCodes(), compress.getFrequencies(), selectedFile.getName());
            String codeSequence = header.getCodeSequence();

            updateHeader(compressedFile.getName(), selectedFile.getName(), originalSize, compressedSize, compressionRatio, codeSequence);
            updateStatistics(originalSize, compressedSize, compressionRatio);
            updateHuffmanTable();

            showAlert("Compression Successful", "File compressed successfully to: " + compressedFile.getAbsolutePath());
        } catch (IOException e) {
            showAlert("Error", "Compression failed: " + e.getMessage());
        }
    }

    private void handleDecompress(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select File to Decompress");
        selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile == null) {
            showAlert("No File Selected", "Please select a file to decompress.");
            return;
        }

        try {
            
            Decompress decompress = new Decompress();
            File decompressedFile = decompress.decompress(selectedFile);

            headerBox.getChildren().clear();
            statisticsBox.getChildren().clear();
            huffmanTable.getItems().clear();

            showAlert("Decompression Successful", "File decompressed successfully to: " + decompressedFile.getAbsolutePath());
        } catch (IOException e) {
            showAlert("Error", "Decompression failed: " + e.getMessage());
        }
    }



    

   

    private Tab createStatisticsTab() {
        Tab tab = new Tab("Statistics");
        statisticsBox = new VBox();
        statisticsBox.setAlignment(Pos.TOP_LEFT);
        statisticsBox.setPadding(new Insets(10));
        statisticsBox.setStyle("-fx-background-color: #0C6478;");
        statisticsBox.getChildren().add(new Label("No statistics available.")); // Placeholder

        tab.setContent(statisticsBox);
        return tab;
    }

    private Tab createHuffmanTableTab() {
        Tab tab = new Tab("Huffman Table");
        VBox box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));
        box.setStyle("-fx-background-color: #0C6478;");

        if (huffmanTable != null) {
            box.getChildren().add(huffmanTable);
        } else {
            box.getChildren().add(new Label("Huffman table not available."));
        }

        tab.setContent(box);
        return tab;
    }

    private Tab createHeaderTab() {
        Tab tab = new Tab("Header");
        headerBox = new VBox();
        headerBox.setAlignment(Pos.TOP_LEFT);
        headerBox.setPadding(new Insets(10));
        headerBox.setStyle("-fx-background-color: #0C6478;");
        headerBox.getChildren().add(new Label("No header details available.")); // Placeholder

        tab.setContent(headerBox);
        return tab;
    }

    private TableView<HuffmanTableRow> initializeHuffmanTable() {
        TableView<HuffmanTableRow> table = new TableView<>();

        // Define columns
        TableColumn<HuffmanTableRow, String> characterCol = new TableColumn<>("Character");
        characterCol.setCellValueFactory(new PropertyValueFactory<>("character"));

        TableColumn<HuffmanTableRow, Integer> asciiCol = new TableColumn<>("ASCII Value");
        asciiCol.setCellValueFactory(new PropertyValueFactory<>("ascii"));

        TableColumn<HuffmanTableRow, Integer> frequencyCol = new TableColumn<>("Frequency");
        frequencyCol.setCellValueFactory(new PropertyValueFactory<>("frequency"));

        TableColumn<HuffmanTableRow, String> codeCol = new TableColumn<>("Huffman Code");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("code"));

        TableColumn<HuffmanTableRow, String> sizeCol = new TableColumn<>("Size");
        sizeCol.setCellValueFactory(new PropertyValueFactory<>("size"));

        // Add columns to the table
        table.getColumns().addAll(characterCol, asciiCol, frequencyCol, codeCol, sizeCol);

        // Apply CSS styles for the table headers
        table.setStyle(
            "-fx-table-header-row {"
            + "    -fx-background-color: linear-gradient(to bottom, #4DB1CC, #1B879F);" // Gradient header
            + "    -fx-font-family: 'Segoe UI', Calibri, Arial, sans-serif;" // Matching font family
            + "    -fx-font-size: 14px;" // Header font size
            + "    -fx-font-weight: bold;" // Bold header text
            + "    -fx-text-fill: white;" // White header text
            + "    -fx-alignment: CENTER;" // Center alignment
            + "} "
        );

        // Style for individual columns (text alignment and font color)
        String columnStyle = "-fx-alignment: CENTER; "
            + "-fx-font-size: 12px; "
            + "-fx-font-family: 'Segoe UI', Calibri, Arial, sans-serif; "
            + "-fx-text-fill: #073A4B; "
            + "-fx-font-weight: bold;";

        characterCol.setStyle(columnStyle);
        asciiCol.setStyle(columnStyle);
        frequencyCol.setStyle(columnStyle);
        codeCol.setStyle(columnStyle);
        sizeCol.setStyle(columnStyle);

        // Optional: Add light gray grid lines and table background
        table.setStyle(
            "-fx-background-color: white;" // Table background
            + "-fx-border-color: lightgray;" // Light gray border
            + "-fx-border-width: 1px;" // Border width
            + "-fx-table-cell-border-color: lightgray;" // Cell border color
            + "-fx-grid-lines-visible: true;" // Grid lines visible
        );

        // Set table size (example: 600px width and 400px height)
        table.setPrefWidth(600);  // Set preferred width of the table
        table.setPrefHeight(400); // Set preferred height of the table

        return table;
    }

    private HBox createHeaderRow(String label, String value) {
        Label keyLabel = new Label(label);
        keyLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        keyLabel.setTextFill(Color.web("#FFFFFF"));

        Label valueLabel = new Label(value);
        valueLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 14));
        valueLabel.setTextFill(Color.web("#A9D1E4"));

        HBox row = new HBox(10, keyLabel, valueLabel);
        row.setAlignment(Pos.CENTER_LEFT);

        return row;
    }

    private void updateStatistics(long originalSize, long compressedSize, double compressionRatio) {
        statisticsBox.getChildren().clear();
        statisticsBox.getChildren().addAll(
            createHeaderRow("Original Size:", originalSize + " bytes"),
            createHeaderRow("Compressed Size:", compressedSize + " bytes"),
            createHeaderRow("Compression Ratio:", String.format("%.2f%%", compressionRatio))
        );
    }

    private void updateHuffmanTable() {
        if (selectedFile == null)
            return;

        ObservableList<HuffmanTableRow> tableData = FXCollections.observableArrayList();

        try {
            int[] frequencies = FrequencyCounter.countFrequencies(selectedFile);
            HuffmanTree huffmanTree = new HuffmanTree();
            huffmanTree.buildTreeFromFrequencies(frequencies);
            String[] codes = new String[256];
            huffmanTree.generateCodes(codes);
            for (int i = 0; i < frequencies.length; i++) {
                if (frequencies[i] > 0) {
                    tableData.add(new HuffmanTableRow((char) i, i, frequencies[i], codes[i]));
                }
            }

            huffmanTable.setItems(tableData);
        } catch (Exception e) {
            showAlert("Error", "Failed to populate Huffman table: " + e.getMessage());
        }
    }
    private void updateHeader(String compressedFileName, String originalFileName, long originalSize, long compressedSize, double compressionRatio, String codeSequence) {
        headerBox.getChildren().clear();

        headerBox.getChildren().addAll(
            createHeaderRow("Compressed File:", compressedFileName),
            createHeaderRow("Original File:", originalFileName),
            createHeaderRow("Original Size:", originalSize + " bytes"),
            createHeaderRow("Compressed Size:", compressedSize + " bytes"),
            createHeaderRow("Compression Ratio:", String.format("%.2f%%", compressionRatio))
        );

        // Create a TextArea for the code sequence
        Label codeLabel = new Label("Code Sequence:");
        codeLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        codeLabel.setTextFill(Color.web("#FFFFFF"));

        TextArea codeTextArea = new TextArea(codeSequence);
        codeTextArea.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 14));
        codeTextArea.setWrapText(true); // Enable text wrapping
        codeTextArea.setEditable(false); // Make it read-only

        // Set the background color to match the header color
        codeTextArea.setStyle("-fx-control-inner-background: #0C6478; -fx-text-fill: #A9D1E4; "
            + "-fx-border-color: transparent; -fx-font-family: 'Segoe UI';");

        headerBox.getChildren().addAll(codeLabel, codeTextArea);
    }


    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
