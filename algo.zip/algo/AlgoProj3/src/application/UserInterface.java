package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;

public class UserInterface {
	private final Graph graph;
	private final MapVisualization mapVisualization;

	public UserInterface(Graph graph) {
		this.graph = graph;
		this.mapVisualization = new MapVisualization("file:hh.jpg");
	}

	public Parent createRoot() {
		BorderPane mainLayout = new BorderPane();

		// Center: Map visualization
		mapVisualization.initializeMap();

		// Convert LinkedList to ArrayList
		ArrayList<CaptalCityNode> cities = new ArrayList<>(graph.getCities());
		mapVisualization.highlightCities(cities);

		StackPane mapContainer = new StackPane(mapVisualization.getMapPane());
		mapContainer.setPadding(new Insets(5));

		// Set dynamic sizing for the map
		mapContainer.setPrefSize(900, 600);
		mapVisualization.getMapPane().setPrefSize(900, 600);

		mapContainer.setAlignment(Pos.CENTER);

		mainLayout.setCenter(mapContainer);

		// Right: Control panel
		VBox controlPanel = createControlPanel();
		controlPanel.setStyle(
				"-fx-background-color: #EAF2F8; -fx-border-color: #A9CCE3; -fx-border-width: 2px; -fx-padding: 10px; -fx-border-radius: 5px;");
		controlPanel.setPrefWidth(280); // Adjust the width of the control panel
		mainLayout.setRight(controlPanel);

		return mainLayout;
	}

	private VBox createControlPanel() {
		VBox controlPanel = new VBox(15); // Spacing of 15 between elements
		controlPanel.setPadding(new Insets(15));
		controlPanel.setStyle(
				"-fx-background-color: #F2F4F4; -fx-border-color: #34495E; -fx-border-width: 2px; -fx-border-radius: 10px;");

		// Create Labels and Input Fields
		Label sourceLabel = new Label("Source:");
		sourceLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");
		ComboBox<CaptalCityNode> sourceComboBox = createCityComboBox("Select Source");

		Label targetLabel = new Label("Target:");
		targetLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");
		ComboBox<CaptalCityNode> targetComboBox = createCityComboBox("Select Target");

		Label filterLabel = new Label("Filter:");
		filterLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");
		ComboBox<String> filterComboBox = createFilterComboBox();

		TextArea pathOutput = createReadOnlyTextArea();
		TextField distanceOutput = createReadOnlyTextField();
		TextField costOutput = createReadOnlyTextField();
		TextField timeOutput = createReadOnlyTextField();

		Button calculateButton = createCalculateButton(sourceComboBox, targetComboBox, filterComboBox, pathOutput,
				distanceOutput, costOutput, timeOutput);

		Button clearButton = createClearButton(pathOutput, distanceOutput, costOutput, timeOutput);

		// Use GridPane for layout
		GridPane gridPane = new GridPane();
		gridPane.setHgap(10); // Horizontal gap
		gridPane.setVgap(15); // Vertical gap
		gridPane.setPadding(new Insets(10));

		// Add elements to the GridPane
		gridPane.add(sourceLabel, 0, 0);
		gridPane.add(sourceComboBox, 1, 0);
		gridPane.add(targetLabel, 0, 1);
		gridPane.add(targetComboBox, 1, 1);
		gridPane.add(filterLabel, 0, 2);
		gridPane.add(filterComboBox, 1, 2);

		// Add buttons to a separate row
		HBox buttonBox = new HBox(10);
		buttonBox.setAlignment(Pos.CENTER);
		buttonBox.getChildren().addAll(calculateButton, clearButton);

		gridPane.add(buttonBox, 0, 3, 2, 1); // Span two columns
		Label pathLabel = new Label("Path:");
		pathLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");

		Label disLabel = new Label("Distance:");
		disLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");

		Label costLabel = new Label("Cost:");
		costLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");

		Label timeLabel = new Label("Time:");
		timeLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #1B4F72;");

		// Add output fields to the VBox
		controlPanel.getChildren().addAll(gridPane, pathLabel, pathOutput, disLabel, distanceOutput, costLabel,
				costOutput, timeLabel, timeOutput);

		return controlPanel;
	}

	private ComboBox<CaptalCityNode> createCityComboBox(String promptText) {
		ComboBox<CaptalCityNode> comboBox = new ComboBox<>();
		comboBox.setPromptText(promptText);
		comboBox.getItems().addAll(graph.getCities());
		return comboBox;
	}

	private ComboBox<String> createFilterComboBox() {
		ComboBox<String> comboBox = new ComboBox<>();
		comboBox.getItems().addAll("Shortest", "Fastest", "Cheapest");
		comboBox.setValue("Shortest");
		return comboBox;
	}

	private TextArea createReadOnlyTextArea() {
		TextArea textArea = new TextArea();
		textArea.setEditable(false);
		textArea.setWrapText(true);
		textArea.setPrefHeight(80); // Adjust height
		return textArea;
	}

	private TextField createReadOnlyTextField() {
		TextField textField = new TextField();
		textField.setEditable(false);
		return textField;
	}

	private Button createCalculateButton(ComboBox<CaptalCityNode> sourceComboBox,
			ComboBox<CaptalCityNode> targetComboBox, ComboBox<String> filterComboBox, TextArea pathOutput,
			TextField distanceOutput, TextField costOutput, TextField timeOutput) {
		Button button = new Button("Run");
		button.setOnAction(event -> {
			CaptalCityNode sourceCity = sourceComboBox.getValue();
			CaptalCityNode targetCity = targetComboBox.getValue();
			String filter = filterComboBox.getValue();

			if (sourceCity == null || targetCity == null) {
				showErrorDialog("Please select both source and target cities.");
				return;
			}

			Dijkstra dijkstra = new Dijkstra();
			Route result = null;

			if ("Shortest".equals(filter)) {
				result = dijkstra.findShortestPath(sourceCity, targetCity, graph);
			} else if ("Fastest".equals(filter)) {
				result = dijkstra.findFastestPath(sourceCity, targetCity, graph);
			} else if ("Cheapest".equals(filter)) {
				result = dijkstra.findCheapestPath(sourceCity, targetCity, graph);
			}

			if (result != null) {
				mapVisualization.clearMap();
				ArrayList<CaptalCityNode> cities = new ArrayList<>(graph.getCities());
				mapVisualization.highlightCities(cities);
				mapVisualization.drawPath(new ArrayList<>(result.getPath())); // Convert LinkedList to ArrayList
				updateUI(result, pathOutput, distanceOutput, costOutput, timeOutput);
			} else {
				showErrorDialog("No valid path found for the selected filter.");
			}
		});

		return button;
	}

	private Button createClearButton(TextArea pathOutput, TextField distanceOutput, TextField costOutput,
			TextField timeOutput) {
		Button button = new Button("Clear");
		button.setOnAction(event -> {
			pathOutput.clear();
			distanceOutput.clear();
			costOutput.clear();
			timeOutput.clear();
			mapVisualization.clearMap();
			ArrayList<CaptalCityNode> cities = new ArrayList<>(graph.getCities());
			mapVisualization.highlightCities(cities);
		});
		return button;
	}

	private void updateUI(Route route, TextArea pathOutput, TextField distanceOutput, TextField costOutput,
			TextField timeOutput) {
		// Update the path details in the UI
		StringBuilder pathString = new StringBuilder();
		for (CaptalCityNode city : route.getPath()) {
			if (pathString.length() > 0) {
				pathString.append(" -> ");
			}
			pathString.append(city.getName());
		}

		pathOutput.setText(pathString.toString());
		distanceOutput.setText(String.format("%.2f km", route.getTotalDistance()));
		costOutput.setText(String.format("%.2f $", route.getTotalCost()));
		timeOutput.setText(String.format("%.2f min", route.getTotalTime()));
	}

	private void showErrorDialog(String message) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}
}
