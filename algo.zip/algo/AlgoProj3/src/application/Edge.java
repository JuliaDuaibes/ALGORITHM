package application;
/**
 * The Edge class represents a connection between two capital cities in a graph.
 * It stores the source city, target city, distance, travel time, and travel cost.
 * This class is used in graph-based algorithms for route optimization and analysis.
 */

public class Edge {
    private CaptalCityNode source;
    private CaptalCityNode target;
    private double distance;
    private double travelTime;
    private double cost;

    public Edge(CaptalCityNode source, CaptalCityNode target, double distance, double travelTime, double cost) {
        this.source = source;
        this.target = target;
        this.distance = distance;
        this.travelTime = travelTime;
        this.cost = cost; 
    }

    public CaptalCityNode getSource() {
        return source;
    }

    public CaptalCityNode getTarget() {
        return target;
    }

    public double getDistance() {
        return distance;
    }

    public double getTravelTime() {
        return travelTime;
    }

    public double getCost() {
        return cost; // Ensure cost is returned
    }
}
